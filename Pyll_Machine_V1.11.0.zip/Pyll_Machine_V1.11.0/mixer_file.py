class Mixer:
    def __init__(self,pygame,min_vol):
        self.pygame = pygame
        self.sounds = []
        self.min_vol = min_vol
    def create(self,sound_path,max_repeats,repeat_gap,start_volume,div_volume):
        None
    def main(self,old_volume,volume):
        None
                
                
            
            
if __name__ == "__main_":
    import pygame
    pygame.init()
    pygame.mixer.init(buffer=64,frequency=48000)
    mixer = Mixer(pygame = pygame,min_vol = 0.005)
    mixer.create("./sound_effects/paste tone.mp3",10,250,1,2)
    while len(mixer.sounds) > 0:
        #print("ok")
        mixer.main(1,1)
    
    mixer.create("./sound_effects/save tone.mp3",10,750,0.5,2)
    while len(mixer.sounds) > 0:
        #print("ok")
        mixer.main(1,1)
    #pygame.time.wait(1000)
    mixer.create("./sound_effects/copy tone.mp3",10,500,1,2)
    while len(mixer.sounds) > 0:
        #print("ok")
        mixer.main(1,1)
    mixer.create("./sound_effects/paste tone.mp3",10,500,1,2)
    while len(mixer.sounds) > 0:
        #print("ok")
        mixer.main(1,1)

import pygame, librosa, numpy


try:
    print("O")
    y, sr = librosa.load("./sound_effects/paste tone.mp3")
except:
    print("OK")
print(type(y),type(sr))
