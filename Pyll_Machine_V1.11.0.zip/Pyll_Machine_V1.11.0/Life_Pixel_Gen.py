from Pyll_Machine import UNIIN, UNIOUT, loadF, saveF
from clipboard import copy as SetC, paste as GetC

off_name = "Life Pixel Off"
on_name = "Life Pixel"

off = loadF("saves",off_name,False)
on = loadF("saves",on_name,False)

x_off = 53
y_off = 60

#print(on[0:10])
select = 2

if select == 1:
    cont = ("""
'''''''''''''
'''''''''''''
''######'##''
''######'##''
'''''''''##''
''##'''''##''
''##'''''##''
''##'''''##''
''##'''''''''
''##'######''
''##'######''
'''''''''''''
''''''''''''' """)
elif select == 2:
    cont = ("""
'#'
'#'
'#' """)



cont = cont[1:-1] #removes the "new line"s
splt = cont.split("\n")
#print(splt)
blue = {}

for y in range(len(splt)):
    for x in range(len(splt[y])):
        ok = True
        if splt[y][x] == "#":
            cur = on
        elif splt[y][x] == "'":
            cur = off
        else:
            ok = False

        if ok:
            for i in cur:
                new_pos = (i[0]+x*x_off, i[1]+y*y_off)
                blue[new_pos] = cur[i]


out = UNIOUT(blue,True,True,True)
SetC(out)
        

