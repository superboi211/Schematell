import re
try:
    from encoder import decode_string, encode_number
    from compressV3 import compressV3
    from levelCodeConverter import convertV1toV3
    from loadCode import loadFromInput
except:
    from V3_encoder.encoder import decode_string, encode_number
    from V3_encoder.compressV3 import compressV3
    from V3_encoder.levelCodeConverter import convertV1toV3
    from V3_encoder.loadCode import loadFromInput


def optimize_code(levelTypeIndicator, cellarray):
    if levelTypeIndicator == "V1":
        # Optimizing V1 code
        cellarray = re.sub(r"([125-8])\.[0-3](\.\d+\.\d+)", r"\1.0\2", cellarray)
        cellarray = re.sub(r"(4)\.[02](\.\d+\.\d+)", r"\1.0\2", cellarray)
        cellarray = re.sub(r"(4)\.[13](\.\d+\.\d+)", r"\1.1\2", cellarray)
        
        # Returning the cell array
        return cellarray
        
    elif levelTypeIndicator == "V3":
        # Optimizing V3 code
        
        # g  rcw rccw m  s  p  w  e  t
        # 01 23  45   67 89 ab cd ef gh
        # ij kl  mn   op qr st uv wx yz
        # AB CD  EF   GH IJ KL MN OP QR
        # ST UV  WX   YZ !$ %& +- .= ?^
        # + empty
        # } {
        
        # rotator cw
        cellarray = re.sub(r"[kCU]", r"2", cellarray)
        cellarray = re.sub(r"[lDV]", r"3", cellarray)
        
        # rotator ccw
        cellarray = re.sub(r"[mEW]", r"4", cellarray)
        cellarray = re.sub(r"[nFX]", r"5", cellarray)
        
        # slide
        cellarray = re.sub(r"I", r"8", cellarray)
        cellarray = re.sub(r"J", r"9", cellarray)
        cellarray = re.sub(r"!", r"q", cellarray)
        cellarray = re.sub(r"\$", r"r", cellarray)
        
        # push
        cellarray = re.sub(r"[sK%]", r"a", cellarray)
        cellarray = re.sub(r"[tL&]", r"b", cellarray)
        
        # wall
        cellarray = re.sub(r"[uM+]", r"c", cellarray)
        cellarray = re.sub(r"[vM-]", r"d", cellarray)
        
        # enemy
        cellarray = re.sub(r"[wO.]", r"e", cellarray)
        cellarray = re.sub(r"[xP=]", r"f", cellarray)
        
        # trash
        cellarray = re.sub(r"[yQ?]", r"g", cellarray)
        cellarray = re.sub(r"[zR^]", r"h", cellarray)
        
        # Returning the cell array
        return cellarray

def compressV2(level_data,x,y):
    length = 1
    ln = len(level_data)
    out = ""
    for i in range(ln):
        cur = level_data[i]
        if i < ln-1:
            eof = False
            if level_data[i] == level_data[i+1]:
                skip = True
            else:
                skip = False
        else:
            eof = True
            skip = False

        if skip:
            length += 1
        else:
            #if not (eof and cur == "}"): #who cares about empy spaces at the end
            #    
            if length > 3:
                while length > 0:
                    sub = 74 if length > 74 else length
                    length -= sub
                    out += (cur+")"+encode_number(sub-1))
            else:
                for i in range(length):
                    out += cur
            length = 1
    return out

# Accepting an input of the level code

def main(levelcode,compress_level,optimize):
    #print("Paste level code here: ", end="")
    levelcode = levelcode

    # Loading the inputed code
    inputData = loadFromInput(levelcode)


    
    inputData = convertV1toV3(inputData)
    
    # Optimize V3 code
    if optimize:
        inputData[3] = optimize_code(inputData[0], inputData[3], )
    
    # Compress V3 code
    if compress_level == 0:
        "Do nothing"
    if compress_level == 1:
        inputData[0] = "V2"
        inputData[3] = compressV2(inputData[3], decode_string(inputData[1]), decode_string(inputData[2]))
    if compress_level == 2:
        inputData[3] = compressV3(inputData[3], decode_string(inputData[1]), decode_string(inputData[2]))

    #print(inputData)
    # Printing the output
    return ";".join(inputData)

if __name__ == "__main__":
    print(main("V1;87;27;;5.0.0.26,3.0.6.11,3.0.6.12,3.0.6.13,3.0.6.14,3.0.6.15,3.0.6.16,3.0.6.17,3.0.6.18,3.0.6.19,3.0.6.20,5.0.7.11,5.0.7.12,5.0.7.13,5.0.7.14,5.0.7.15,5.0.7.16,5.0.7.17,5.0.7.18,5.0.7.19,5.0.7.20,2.0.8.11,2.0.8.12,2.0.8.13,2.0.8.14,2.0.8.15,2.0.8.16,2.0.8.17,2.0.8.18,2.0.8.19,2.0.8.20,4.0.9.11,4.1.9.12,4.1.9.13,4.1.9.14,4.1.9.15,4.1.9.16,4.1.9.17,4.1.9.18,4.1.9.19,4.1.9.20,1.0.10.11,1.0.10.12,1.0.10.13,1.0.10.14,1.0.10.15,1.0.10.16,1.0.10.17,1.0.10.18,1.0.10.19,1.0.10.20,2.1.11.18,3.1.12.17,2.1.13.14,5.1.14.14,3.1.15.11,2.1.15.14,2.1.16.9,5.1.16.14,2.1.17.9,1.1.17.11,5.1.17.14,5.1.18.9,5.1.18.14,5.1.19.9,3.0.19.10,2.0.19.14,2.1.20.9,5.0.86.0;;",1,False))
    #print(encode_number(0))
