class Mixer:
    def __init__(self,pygame,min_vol,volume):
        self.pygame = pygame
        self.sounds = []
        self.min_vol = min_vol
        self.volume = volume
    def create(self,sound_path,max_repeats,repeat_gap,start_volume,div_volume):
        if self.volume > 0:
            cur_vol = start_volume
            cur_nub = 0
            cur_index = len(self.sounds)
            self.sounds.append([-1])
            cur = self.sounds[cur_index]
            while cur_nub < max_repeats and cur_vol > self.min_vol:
                cur.append([repeat_gap*cur_nub,self.pygame.mixer.Sound(sound_path)])
                cur[cur_nub+1][1].set_volume(cur_vol*self.volume)
                #print(cur[cur_nub+1][1].get_volume(),"making")
                cur_nub += 1
                cur_vol /= div_volume
            #print(self.sounds)
            time = self.pygame.time.get_ticks()
            cur[0] = (repeat_gap*cur_nub) + cur[1][1].get_length() + time
            for i in range(1,len(cur)):
                cur[i][0] += time
        
    def main(self,volume):
        time = self.pygame.time.get_ticks()
        if self.volume > 0:
            vol_change = self.volume != volume
            vol_mult = volume / self.volume
        for i in range(len(self.sounds)-1,-1,-1): #running through the list backwards helps with deleting stuff
            for j in range(1,len(self.sounds[i])):
                if self.volume > 0:
                    if vol_change:
                        print("OK")
                        self.sounds[i][j][1].set_volume(self.sounds[i][j][1].get_volume()*vol_mult)
                cur_nub = self.sounds[i][j][0]
                if cur_nub != -1 and cur_nub < time:
                    self.sounds[i][j][0] = -1
                    chan = self.pygame.mixer.find_channel(True)
                    chan.play(self.sounds[i][j][1])
                    #print(self.sounds[i][j][1].get_volume(),self.sounds[i][j][1].get_num_channels(),"doing")
            if self.sounds[i][0]<time:
                #print(self.sounds[i][0],time)
                self.sounds.pop(i)
        self.volume = volume
                
                
            
            
if __name__ == "__main__":
    import pygame
    pygame.init()
    pygame.mixer.init(buffer=64,frequency=48000)
    mixer = Mixer(pygame = pygame,min_vol = 0.005,volume=1)
    mixer.create("./sound_effects/paste tone.mp3",10,250,1,2)
    while len(mixer.sounds) > 0:
        #print("ok")
        mixer.main(1)
    
    mixer.create("./sound_effects/save tone.mp3",10,750,0.5,2)
    while len(mixer.sounds) > 0:
        #print("ok")
        mixer.main(1)
    #pygame.time.wait(1000)
    mixer.create("./sound_effects/copy tone.mp3",10,500,1,2)
    while len(mixer.sounds) > 0:
        #print("ok")
        mixer.main(1)
    mixer.create("./sound_effects/paste tone.mp3",10,500,1,2)
    while len(mixer.sounds) > 0:
        #print("ok")
        mixer.main(1)
