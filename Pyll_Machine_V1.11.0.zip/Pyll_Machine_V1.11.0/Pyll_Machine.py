import math, sys as trans, os, subprocess
from time import sleep
from math import floor as flr, ceil
from copy import deepcopy as dcopy
from random import random as rand
from glob import glob as glob #glob
from warnings import warn

#print(subprocess.CalledProcessError)
#print(EOFError())

if __name__ == "__main__":
    def install(package):
        subprocess.check_call([trans.executable, "-m", "pip", "install", package])
    
    module_errors = [False,False,False,False]
    try:
        from clipboard import copy as SetC, paste as GetC
    except:
        module_errors[0] = True
    try:
        import numpy
    except:
        module_errors[1] = True
    try:
        from Raster_Test import line_render, circle_render
        import pygame
        pygame.init()
    except:
        module_errors[2] = True
    try:
        from PIL import Image
    except:
        module_errors[3] = True

    #clip = True

    if module_errors.count(True) != 0:
        print("DO NOT PANIC\nSome moduals are missing, and are being installed\n\nPlease wait\n")
        #input("\nHit enter to exit")
        #0 = none or successful download, 1 = mispell or fail to download
        
        modules = ["clipboard","numpy","pygame","pillow"]
        install_errors = [0 for i in modules]
        
        for i in range(len(modules)):
            if module_errors[i] == True:
                try:
                    install(modules[i])
                except subprocess.CalledProcessError:
                    install_errors[i] = 1

        #input(install_errors)

        if install_errors.count(1) == 0:
            exec(open("Pyll_Machine.py").read())
        else:
            print("\nSomething went wrong when downloading, hit enter to exit")
            input()
        trans.exit()
from V3_encoder.levelCodeOptimizer import main as V3OUT



from level import Level
from mixer_fluid import Mixer


def render():
    global screen,disar,gx,gy,cellsA,colors,details,running,min_size,animation_move,calc_last,calc_gap
    global frame_calc, play, UI_size, UI_base_gap, UI_button_gap, UI_cell_gap, UI, UI_positions
    global cosi, ms, min_interval, min_small_interval, TUI, render_ui, tab, grid_size, grid_toggle
    global SUI, cur_GUI
    #yes, that many globals is nesesary
    
    cur_time = pygame.time.get_ticks()
    tmult = (cur_time - calc_last)/calc_gap #returns a float from 0 to 1 determining how far though the movement it is
    nub_rendered = 0
    screen.fill((255,255,255) if tab else (0,0,0)) #blanks the screen
    
    sx = gx/(disar[1][0]-disar[0][0]) #determines how big each cell is in float pixels
    sy = gy/(disar[1][1]-disar[0][1])
    nx = (disar[1][0]-disar[0][0])/gx #number of pixels per screen
    ny = (disar[1][1]-disar[0][1])/gy
    gsx = sx*grid_size
    gsy = sy*grid_size

    render_detail = (sx>=min_size or sy>=min_size)
    render_base = cur_texture_pack == -1 or not (sx>=min_texture_size or sy>=min_texture_size)

    cur_details = details if (sx>=min_texture_size or sy>=min_texture_size) else default_details
    
    if render_detail:
        render_movement = calc_gap > min_interval
    else:
        render_movement = calc_gap > min_small_interval

    if tmult > 1: #helps with nukes
        render_movement = False

    
    if grid_toggle and (gsx>=1 or gsy>=1) and not tab:
        color = (50,50,50)
        for cy in range(flr(disar[0][1]),ceil(disar[1][1])+1):
  
            cur_x = 0
            cur_y = cy

            difx = 0
            dify = cur_y - disar[0][1]-0.5
           
            py = dify/ny-gsy/2
            fpy = flr(py)
            pygame.draw.rect(screen,color,(0,fpy,gx,flr(gsy)))
        for cx in range(flr(disar[0][0]),ceil(disar[1][0])+1):

            cur_x = cx
            cur_y = 0

            difx = cur_x - disar[0][0]-0.5
            dify = 0
            
            px = difx/nx-gsx/2
            fpx = flr(px)
            pygame.draw.rect(screen,color,(fpx,0,flr(gsx),gy))
        
    
    for i in cellsA: #renders all the cells and details
        cur = cellsA[i]
        color = cur[0]
         

        olds = cur[2:4]
        
        if tuple(olds) == i or not (animation_move and play and render_movement):
            
            cur_x = i[0]
            cur_y = i[1]
        else:
            cur_x = (i[0]-olds[0])*(tmult)+olds[0]#finds where it should be, since it's in-between steps
            cur_y = (i[1]-olds[1])*(tmult)+olds[1]
            #print(tmult,olds[0]-i[0],cur_x)
        difx = cur_x - disar[0][0]
        dify = cur_y - disar[0][1]
        

        px = difx/nx-sx/2
        py = dify/ny-sy/2
        
        if (px >= -sx and px <= gx) and (py >= -sy and py <= gy):#little check to stop rendering things off screen
            #print(cur,cur[4] != cur[5])
            nub_rendered += 1

            
            if  cur[4] == cur[5] or not animation_rotate:
                    if (render_base or color >= len(texture_images_names)):
                        fpx = flr(px)
                        fpy = flr(py)
                        pygame.draw.rect(screen,colors[color],(fpx,fpy,flr(px+sx)-fpx,flr(py+sy)-fpy))
                    rotate_base = cellsA[i][1]
                    rotate = -rotate_base/2*math.pi
                    
                    co = -1
                    si = -1
                
            if (animation_rotate or animation_rotate_half) and cur[4] != cur[5]:
                
                rotate_base = (cur[4]-cur[5])*tmult+cur[5]
                rotate = -rotate_base/2*math.pi
                co = math.cos(rotate)
                si = math.sin(rotate)
                if animation_rotate:
                    #uses trig functions to rotate the cell, only enabled with animation_rotate
                    cen = [px+sx/2,py+sy/2]#finds the center of rotation
                    poly = []
                    for k in [[px,py],[px,py+sy],[px+sx,py+sy],[px+sx,py]]:#jank
                        newx = (co*(k[0]-cen[0]))+(si*(k[1]-cen[1]))+cen[0]#does the math
                        newy = (co*(k[1]-cen[1]))-(si*(k[0]-cen[0]))+cen[1]
                        poly.append([newx,newy])
                    pygame.draw.polygon(screen,colors[color],poly)
            
                
            typ = cellsA[i][0]
            det = cur_details[typ]
            if len(det) > 0 and render_detail:
                if co == -1:
                    co = math.cos(rotate)
                    si = math.sin(rotate)
                for j in det:
                    newdet = []
                    for k in j[1:]:
                        newx = (co*(k[0]-0.5))+(si*(k[1]-0.5))+0.5
                        newy = (co*(k[1]-0.5))-(si*(k[0]-0.5))+0.5
                        newx = newx*sx+px
                        newy = newy*sy+py
                        newdet.append([newx,newy])
                    pygame.draw.polygon(screen,j[0],newdet)

    if render_ui:
        # A bit to do the ghost block
        if cur_ghost[0] and not ms[2]:
            if len(cur_ghosts[1]) == 0:
                off_x,off_y = 0,0
                cur_dict = {(0,0):cur_ghost[3:]}
            else:
                off_x,off_y = cur_ghosts[2][0]//2,cur_ghosts[2][1]//2
                cur_dict = cur_ghosts[1]
            for i in cur_dict:
                difx = abs(disar[0][0]-disar[1][0])
                dify = abs(disar[0][1]-disar[1][1])
                mpx = msx/gx*difx + disar[0][0]
                mpy = msy/gy*dify + disar[0][1]
                mpx = flr(mpx+0.5)
                mpy = flr(mpy+0.5)
        
                cur_cell = cur_dict[i]
                cur_x = i[0]-off_x
                cur_y = i[1]-off_y
                color = cur_cell[0]
                difx = cur_x+mpx-disar[0][0]
                dify = cur_y+mpy-disar[0][1]
                px = difx/(disar[1][0]-disar[0][0])*gx-sx/2
                py = dify/(disar[1][1]-disar[0][1])*gy-sy/2
                #print(cur,cur[4] != cur[5])
                fpx = flr(px)
                fpy = flr(py)

                
                if cur_GUI != 3 and cur_GUI != 4 and cur_GUI != 5 and cur_GUI != 6:
                    pygame.draw.rect(screen,colors[color],(fpx,fpy,flr(px+sx)-fpx,flr(py+sy)-fpy))
                    
                    rotate_base = cur_cell[1]
                    rotate = -rotate_base/2*math.pi
                    co = math.cos(rotate)
                    si = math.sin(rotate)
                    typ = color
                    det = cur_details[typ]
                    if len(det) > 0 and (sx>=min_size or sy>=min_size):
                        for j in det:
                            newdet = []
                            for k in j[1:]:#rotates and moves the points in the detail polys using trig functions
                                newx = (co*(k[0]-0.5))+(si*(k[1]-0.5))+0.5
                                newy = (co*(k[1]-0.5))-(si*(k[0]-0.5))+0.5
                                newx = newx*sx+px
                                newy = newy*sy+py
                                newdet.append([newx,newy])
                            pygame.draw.polygon(screen,j[0],newdet)
                else:
                    pygame.draw.rect(screen,(255,255,255),(fpx,fpy,flr(px+sx)-fpx,flr(py+sy)-fpy))



        # Bit to do the simple/shape UI

        #[[shape ("square"),[x,y,width,height], color, when to delete (-1 if never), min frame_calcs to delete]]
        for i in range(len(SUI)-1,-1,-1):
            
            cur = SUI[i]
            if not (cur_time>cur[3] and cur[4] <= 0):
                if cur[0] == "square":
                    if cur[2] == -1:
                        for j in range(flr(cur[1][0]),flr(cur[1][0]+cur[1][2])):
                            for k in range(flr(cur[1][1]),flr(cur[1][1]+cur[1][3])):
                                color = screen.get_at((j, k))
                                inverse = (abs(color[0]-255),abs(color[1]-255),abs(color[2]-255))
                                pygame.draw.rect(screen,inverse,[j,k,1,1])
                    else: 
                        pygame.draw.rect(screen,cur[2],cur[1])
            else:
                SUI.pop(i)
            cur[4] -= 1
                
    
        # Now a bit to do the UI
        for i in range(len(UI_positions)):
            curpos = UI_positions[i]
            curpos2 = list(curpos)
            curpos2[0:2] = [abs(curpos2[0])-1,abs(curpos2[1])-1]
            
            cur = UI[i]
            if ((curpos2[2][0] and frame_calc == 0) or (curpos2[2][1] and frame_calc != 0)):
                px = UI_base_gap*UI_size + (UI_button_gap * UI_size + UI_size)*curpos2[0]
                py = gy - (UI_base_gap*UI_size + (UI_button_gap * UI_size + UI_size)*curpos2[1] + UI_size)

                if curpos[0]<0:
                    px = px*-1+gx-UI_size

                if curpos[1]<0:
                    py = py*-1+gy-UI_size
                
                if curpos[3] == 0:
                    for j in cur:
                        UI_new = []
                        for k in j[1:]:
                            newx = k[0]*UI_size
                            newy = k[1]*UI_size
                            newx = newx+px
                            newy = newy+py
                            UI_new.append([newx,newy])
                        pygame.draw.polygon(screen,j[0],UI_new)
                elif curpos[3] == 1:
                    screen.blit(cur,(px,py))
        # and the TUI
        for i in range(len(TUI)-1,-1,-1):
            #[rendered text, center in pixels from top left, when to delete (-1 if never, min frame_calcs to delete)]
            cur = TUI[i]
            if not (cur_time>cur[2] and cur[3] <= 0):
                px = cur[1][0]-cur[0].get_width()/2
                py = cur[1][1]-cur[0].get_height()/2
                #print(px,py,cur[1])
                screen.blit(cur[0],(px,py))
            else:
                TUI.pop(i)
            cur[3] -= 1
            





    
    pygame.display.flip()
    #print(nub_rendered)
    #sleep(0.01)

def UNIIN(instr,main_level):
    if main_level > 0:
        global disar, cellsBASE, cellsGEN, cellsROT, cellsPSH

    #print(instr)

    level_data = level.load_string(instr,True)
    
    size = level_data[2]
    dictout = level_data[0]

    if len(dictout) == 0:
        #print("")
        #print("OHNO2")
        return

    if main_level == 2:
        difx = disar[1][0]-disar[0][0]
        dify = disar[1][1]-disar[0][1]
        aspect = difx/dify
        xbased = (size[0],size[0]/aspect)
        ybased = (size[1]*aspect,size[1])
        size = max(xbased,ybased)

        mult = 1.5
        size = [i*mult for i in size]

        disar[0][0]=size[0]/-2
        disar[0][1]=size[1]/-2
        disar[1][0]=size[0]/2
        disar[1][1]=size[1]/2
        
        key = [*dictout.keys()]
        for i in key: #sets the stuff used for animations
            cur = dictout[i]
            dictout[i].append(i[0])
            dictout[i].append(i[1])
            dictout[i].append(cur[1])
            dictout[i].append(cur[1])
        #print(dictout)
        
        if len(dictout)>0:
            cellsBASE = dictout
            (cellsGEN,cellsROT,cellsPSH) = level_data[1]
    elif main_level == 1:
        key = [*dictout.keys()]
        for i in key: #sets the stuff used for animations
            cur = dictout[i]
            dictout[i].append(i[0])
            dictout[i].append(i[1])
            dictout[i].append(cur[1])
            dictout[i].append(cur[1])
        #print("OK",dictout)
        return dictout, size
    else:
        #print("OK")
        return dictout, size

def UNIOUT(dictin,use_v3,compress,optimize):
    global V1map
    
    key = [*dictin.keys()]
    
    keyx = [i[0] for i in key]
    keyy = [i[1] for i in key]
    
    if len(key) > 0:
        up = min(keyy)
        down = max(keyy)
        left = min(keyx)
        right = max(keyx)
        x = (right-left)+1
        y = (down-up)+1
        sx = left
        sy = up
        
        

        outstr = "V1;"+str(x)+";"+str(y)+";;"
        for i in range(len(key)):
            cur = dictin[key[i]]
            if i > 0:
                outstr += ","
            outstr += str(V1map.index(cur[0]))
            outstr += "."
            outstr += str(cur[1])
            outstr += "."
            outstr += str(key[i][0]-sx)
            outstr += "."
            outstr += str((key[i][1]-sy)*-1+y-1)
        
        #print(V3OUT("V1",outstr))
        #outv3 = V3OUT("V1",outstr)
        outstr += ";;"

        valid = True
        for i in key:
            if defaults.count(dictin[i][0]) == 0:
                valid = False

        
        if use_v3 and valid:
            #print(outstr)
            if compress == 1:
                typ = "V2"
            else:
                typ = "V3"
            outstr = V3OUT(outstr,compress,optimize)
        else:
            typ = "V1"
        
        return outstr, typ

class Comp:
    def __init__(self,x,y):
        self.x = x
        self.y = y

    
    
    def Text(self,rx,ry,txt,txt_size,color,cur_last,min_frame_calcs,TUI):
        if type(txt) != type(""):
            warn("Comp.Text should only be given strings")
            return
        txt_split = txt.split("\n")
        font = pygame.font.SysFont("Courier_New", txt_size,True)
        cur_time = pygame.time.get_ticks()
        txt_len = txt_size*(len(txt_split))
        top = self.y*ry-(txt_len/2)
        if top<0:
            top = txt_size/2
        if top+txt_len>self.y:
            top = self.y-txt_len-txt_size/2
        for i in range(len(txt_split)):
            cur = txt_split[i]
            #print(cur)
            txt_cur = font.render(cur, True, color)
            TUI.append([txt_cur,(self.x*rx,top+(i*txt_size)),cur_time+cur_last,min_frame_calcs])

    def Square(self,coords,color,grid_relative,cur_last,min_frame_calcs,SUI,disar):
        tl_x = min(coords[0][0],coords[1][0])
        tl_y = min(coords[0][1],coords[1][1])
        br_x = max(coords[0][0],coords[1][0])
        br_y = max(coords[0][1],coords[1][1])
        if grid_relative:
            difx = abs(disar[0][0]-disar[1][0])
            dify = abs(disar[0][1]-disar[1][1])
            tl_x-=0.5
            tl_y-=0.5
            br_x+=0.5
            br_y+=0.5
            px = (tl_x - disar[0][0])*self.x/difx 
            py = (tl_y - disar[0][1])*self.y/dify
            br_x = (br_x - disar[0][0])*self.x/difx 
            br_y = (br_y - disar[0][1])*self.y/dify
        else:
            px = tl_x
            py = tl_y
        sx = br_x - px
        sy = br_y - py
        fpx,fpy = flr(px),flr(py)
            
   
            
            #px = msx/gx*difx + disar[0][0]
            #py = msy/gy*dify + disar[0][1]
            #px = flr(px+0.5)
            #py = flr(py+0.5)
            
        
        cur_time = pygame.time.get_ticks()
        #[[shape ("square"),[x,y,width,height], color, when to delete (-1 if never), min frame_calcs to delete]]
        SUI.append(["square",[fpx,fpy,flr(fpx+sx)-fpx,flr(fpy+sy)-fpy],color,cur_time+cur_last,min_frame_calcs])
    
    def Selection(self,coords,grid_relative,pixels_wide,cur_last,min_frame_calcs,SUI,disar):
        #print(grid_relative)
        self.Square(coords,-1,grid_relative,cur_last,min_frame_calcs,SUI,disar)
        square = SUI[-1]
        if square[1][2] <= pixels_wide and square[1][3] <= pixels_wide:
            return
        else:
            tl_x,tl_y = square[1][0],square[1][1]
            br_x,br_y = square[1][2]+tl_x,square[1][3]+tl_y
            SUI.pop(-1)
            #print(tl_x,tl_y,br_x,br_y)
            
            coordses = []
            coordses.append([[tl_x,tl_y],[br_x,tl_y+pixels_wide]])
            coordses.append([[tl_x,tl_y+pixels_wide],[tl_x+pixels_wide,br_y-pixels_wide]])
            coordses.append([[tl_x,br_y-pixels_wide],[br_x,br_y]])
            coordses.append([[br_x-pixels_wide,tl_y+pixels_wide],[br_x,br_y-pixels_wide]])

            for coords in coordses:
                #print(coords)
                self.Square(coords,-1,False,cur_last,min_frame_calcs,SUI,disar)

    
    
   
        


def UtFN(string): #this jank is needed so that the file names can have any character that's in unicode
    fn = ""
    ln = len(string)
    for i in range(ln):
        fn += str(ord(string[i]))
        if i != ln-1:
            fn += ","
    return fn

def FNtU(fn):
    fn = os.path.basename(fn)[:-5]
    
    letts = fn.split(",")
    string = ""
    for i in letts:
        string+=chr(int(i))
    return string

def showF(folder): # all_custom/*.rle
    files_basic = glob(folder+"/*.cell")
    files = []
    for i in files_basic:
        files.append(FNtU(i))
    return files

def closeF(folder,name,level_code):
    fnName = "./"+folder+"/"+UtFN(name)+".cell" #fn is short for "file name", but whatever
    file2write=open(fnName,'w')
    file2write.write(level_code)
    file2write.close()
    return None


def openF(folder,name):
    #print("OK")
    fnName = "./"+folder+"/"+UtFN(name)+".cell"
    level_code=open(fnName,'r').read()
    #print("OK")
    return level_code


def saveF(folder,name,cells,use_V3):
    level_code = UNIOUT(cells,use_V3,1,False)[0]
    closeF(folder,name,level_code)
    return None

def loadF(folder,name,main):
    level_code = openF(folder,name)
    cells = UNIIN(level_code,main)
    if main:
        return None
    else:
        return cells
    

class change_fullscreen:
    def __init__(self,x,y):
        self.default = (x,y)
    def set_fullscreen(self,disar,fullscreen,autoset):
        global gx,gy,screen,comp
        pygame.display.quit()
        pygame.display.init()
        
        
        if fullscreen or autoset:
            cur_disp = pygame.display.Info()
            #print(cur_disp)
            gx,gy = cur_disp.current_w,cur_disp.current_h
            if not fullscreen:
                gy-=115
        else:
            (gx,gy) = self.default

        ratio = gx/gy
        dify = abs(disar[0][1]-disar[1][1])
        difx = dify*ratio
        outx = (disar[0][0]+disar[1][0])/2
        disar[0][0] = difx/-2+outx
        disar[1][0] = difx/2+outx
        
        screen = pygame.display.set_mode((gx,gy))
        comp = Comp(x=gx,y=gy)
        
        if fullscreen:
            pygame.display.toggle_fullscreen()

class Find:
    def __init__(self,cell_to_dict_map,collection):
        self.cell_to_dict_map = cell_to_dict_map
        self.collection = collection
    
    def dict(self,cell):
        cur = self.cell_to_dict_map[cell]
        if cur != -1:
            return self.collection[cur]
        else:
            return None
    
    def des(self,cell):
        cur = self.cell_to_dict_map[cell]
        if cur != -1:
            return True
        else:
            return False
    
    def change(self,collection):
        self.collection = collection

def copy_in():
    global cellsA, cellsBASE, frame_calc, play, disar, cur_ghosts

    level_code = GetC()
    out = UNIIN(level_code,1)

    if out != None:
    
        frame_calc = 0
        
        play = False
    
    
        (new_dict,size) = out
        if level_code.endswith("segment"):
            cellsA = dcopy(cellsBASE)
            cur_ghosts = [True,new_dict,size]

            txt = ""
            cur_wait = 0
        else:
            cellsBASE = new_dict
            cellsA = dcopy(cellsBASE)
            midx = (disar[0][0]+disar[1][0])/2
            midy = (disar[0][1]+disar[1][1])/2
            difx = midx - disar[2][0]
            dify = midy - disar[2][1]
            disar[0][0] -= difx
            disar[0][1] -= dify
            disar[1][0] -= difx
            disar[1][1] -= dify
            
            txt = "Level has been loaded"
            cur_wait = 2000
    else:
        txt = "Level code is either empty or invalid"
        cur_wait = 5000
    txt_size = 30
    color = (255,255,255)
    comp.Text(0.5,0.5,txt,txt_size,color,cur_wait,1,TUI)

    


    
    

#print(FNtU(UtFN("test :/,=*🙂")))
    



V1map = [0,2,3,1,5,4,8,6,7,9,10,11]
level = Level(matcher_type=V1map)

if __name__ == "__main__":
    #gx,gy = 850,720
    gx,gy = 600,700
    autoset = True
    fullscreen = False


    '''
    fullscreen_ratio = (2,2)
    max_gy = 1400
    '''#Doesn't do anything


    disar = [[-10,-10],[10,10],[0,0]] #The final one is for original middle co-ords
    min_size = 5 #minimum size of a cell on screen before the details stop being rendered
    min_texture_size = 10 #same as above, but for textures
    min_interval = 10 #minimum interval between computations before the smoove movement stops being rendered
    min_small_interval = 25 #same as above, but applies to detailess blocks
    zoom_speed = 1.5 #multiplier applied each time the scroll wheel moves
    calc_gap = 400 #miliseconds between each compute
    calc_mult = 2 #how much the calc gap is multiplied by when using  Shift + MsWheel
    pan_speed = [1,1] #how many screens panning the camera via WASD moves per second
    render_gap = 16 #miliseconds between each render
    output_gap = 35 #how many frames are rendered before the FPS and GPS gets updated
    min_calc_ratio = 1 #how may times faster calcs happen then renders before switching to high-speed regulation
    grid_size = 0.15 #how wide the grid is compared to a block
    grid_toggle = True
    animation_move = True
    animation_rotate = False #fluidly rotates the entire block
    animation_rotate_half = False #fluidly rotates only the details
    sound_step = 0.05 #how much the sound level changes per button press
    sound_level = 0.5
    music_level = 0.05
    files_shown = 10
    slow_zoom = 0
    use_V3 = True
    cellsGEN,cellsROT,cellsPSH = {},{},{}
    defaults = [0,1,2,3,4,5,6,7,8]
    cell_to_dict_map = [0,2,1,1,-1,-1,-1,-1,-1,-1,1,-1]
    #print(len(cell_to_dict_map),len(V1map))
    
    render_ui = True
    play = False
    skip = False
    tab = False
    
    UI_size = 100 #all the folowing UI values are in some way controlled by this
    UI_base_gap = 0.3
    UI_button_gap = 0.1
    UI_cell_gap = 0.1
    Selection_width = 0.05
    
    cur_ghost = [False,0,0,0,0] #[display?,x,y,type,rotation]
    cur_ghosts = [False,{},[0,0]] #[display?,dict_of_cells,size]
    mixer = Mixer(pygame = pygame,min_vol = 0.005,volume=0.5)
    set_fullscreen = change_fullscreen(gx,gy).set_fullscreen
    
    


    select_area = [[0,0],[0,0]]
    cur_GUI = 0
    calc_last = 0
    render_last = 0
    delta1 = 0
    delta2 = 0
    delta = 0
    delta_render1 = 0
    delta_render2 = 0
    delta_render = 1000
    delta_calc1 = 0
    delta_calc2 = 0
    sound_level_old = 0
    delta_calc = 1000
    ms_pos = (0,0)
    click = False
    ms = (False, False, False)
    old_ms = (False, False, False)
    old_click = False
    old_ms_pos = (0,0)
    last_calc = -1
    frame_calc = 0
    frame_render = 0
    frame_calc_old = -1
    frame_render_old = -1
    valid = False
    place_valid = False
    cosi = {}
    zom = 0
    renders_cur = 0
    ctrl = False
    cur_text = ""
    inUNICODE = ""
    cellsBASE = {}
    cellsA = {}
    cellsA = {}
    cellsGEN = {} # the separate dicts are simply perfect copys of the main ones, but only contain what it says on the tin
    cellsROT = {} # this inproves performance, especially when there are a bunch of inactive cells (e.g. cells without a dedicated dict)
    cellsPSH = {}
    all_the_dicts = [cellsGEN,cellsROT,cellsPSH]
    find = Find(cell_to_dict_map,all_the_dicts)
    ready_to_place = True
    cur_texture_pack = -1
                

    if fullscreen or autoset:
        cur_disp = pygame.display.Info()
        #print(cur_disp)
        gx,gy = cur_disp.current_w,cur_disp.current_h
        if not fullscreen:
            gy-=115

    ratio = gx/gy
    dify = abs(disar[0][1]-disar[1][1])
    difx = dify*ratio
    disar[0][0] = difx/-2
    disar[1][0] = difx/2



    if False:
        device = win32api.EnumDisplayDevices()
        print((device.DeviceName, device.DeviceString))
        settings = win32api.EnumDisplaySettings(device.DeviceName, -1)
        print(settings)
        refresh = getattr(settings, "DisplayFrequency")
        bitdep = getattr(settings, "BitsPerPel")
        print(refresh,bitdep)
        

    comp = Comp(x=gx,y=gy)
        


    cellsBASE = {}#[type,rotation,oldx,oldy,current rotation,old rotation]
    #there is a separate current rotation, as the standard one goes from 0-4 and more than a 90* turn can't be animated well




    ran = flr(rand()*11)


    level_data = ""
    #level_data = "V1;50;50;;2.0.16.18,2.0.17.18,2.0.22.18,3.1.16.19,3.0.20.19,2.0.15.20,1.0.17.20,4.0.19.20,1.0.9.21,1.0.11.21,4.0.17.21,0.1.19.21,3.3.22.21,3.0.24.21,4.0.25.21,2.0.26.21,3.2.9.22,0.0.12.22,3.0.15.22,1.0.17.22,0.3.19.22,1.0.21.22,3.0.25.22,1.0.9.23,1.0.11.23,8.0.13.23,7.0.14.24,7.0.15.24,7.0.16.24,2.0.17.24,4.0.19.24,2.0.21.24,3.0.23.24,4.0.24.24,2.0.25.24;;"
    #^Sawtooth
    #level_data = "V1;50;50;;3.0.27.22,4.0.28.22,3.0.28.23,3.0.21.24,5.0.22.24,1.0.23.24,3.0.28.24,3.0.24.25,5.0.25.25,0.2.26.25,0.2.27.25,0.1.28.25,5.0.29.25,3.0.24.26,5.0.25.26,0.2.26.26,0.2.27.26,0.3.28.26,5.0.29.26,3.0.21.27,5.0.22.27,2.0.23.27,3.0.28.27,3.0.28.28,3.0.27.29,4.0.28.29,6.0.0.0,6.0.1.0,6.0.2.0,6.0.3.0,6.0.4.0,6.0.5.0,6.0.6.0,6.0.7.0,6.0.8.0,6.0.9.0,6.0.10.0,6.0.11.0,6.0.12.0,6.0.13.0,6.0.14.0,6.0.15.0,6.0.16.0,6.0.17.0,6.0.18.0,6.0.19.0,6.0.20.0,6.0.21.0,6.0.22.0,6.0.23.0,6.0.24.0,6.0.25.0,6.0.26.0,6.0.27.0,6.0.28.0,6.0.29.0,6.0.30.0,6.0.31.0,6.0.32.0,6.0.33.0,6.0.34.0,6.0.35.0,6.0.36.0,6.0.37.0,6.0.38.0,6.0.39.0,6.0.40.0,6.0.41.0,6.0.42.0,6.0.43.0,6.0.44.0,6.0.45.0,6.0.46.0,6.0.47.0,6.0.48.0,6.0.49.0,6.0.49.1,6.0.49.2,6.0.49.3,6.0.49.4,6.0.49.5,6.0.49.6,6.0.49.7,6.0.49.8,6.0.49.9,6.0.49.10,6.0.49.11,6.0.49.12,6.0.49.13,6.0.49.14,6.0.49.15,6.0.49.16,6.0.49.17,6.0.49.18,6.0.49.19,6.0.49.20,6.0.49.21,6.0.49.22,6.0.49.23,6.0.49.24,6.0.49.25,6.0.49.26,6.0.49.27,6.0.49.28,6.0.49.29,6.0.49.30,6.0.49.31,6.0.49.32,6.0.49.33,6.0.49.34,6.0.49.35,6.0.49.36,6.0.49.37,6.0.49.38,6.0.49.39,6.0.49.40,6.0.49.41,6.0.49.42,6.0.49.43,6.0.49.44,6.0.49.45,6.0.49.46,6.0.49.47,6.0.49.48,6.0.49.49,6.0.48.49,6.0.47.49,6.0.46.49,6.0.45.49,6.0.44.49,6.0.43.49,6.0.42.49,6.0.41.49,6.0.40.49,6.0.39.49,6.0.38.49,6.0.37.49,6.0.36.49,6.0.35.49,6.0.34.49,6.0.33.49,6.0.32.49,6.0.31.49,6.0.30.49,6.0.29.49,6.0.28.49,6.0.27.49,6.0.26.49,6.0.25.49,6.0.24.49,6.0.23.49,6.0.22.49,6.0.21.49,6.0.20.49,6.0.19.49,6.0.18.49,6.0.17.49,6.0.16.49,6.0.15.49,6.0.14.49,6.0.13.49,6.0.12.49,6.0.11.49,6.0.10.49,6.0.9.49,6.0.8.49,6.0.7.49,6.0.6.49,6.0.5.49,6.0.4.49,6.0.3.49,6.0.2.49,6.0.1.49,6.0.0.49,6.0.0.48,6.0.0.47,6.0.0.46,6.0.0.45,6.0.0.44,6.0.0.43,6.0.0.42,6.0.0.41,6.0.0.40,6.0.0.39,6.0.0.38,6.0.0.37,6.0.0.36,6.0.0.35,6.0.0.34,6.0.0.33,6.0.0.32,6.0.0.31,6.0.0.30,6.0.0.29,6.0.0.28,6.0.0.27,6.0.0.26,6.0.0.25,6.0.0.24,6.0.0.23,6.0.0.22,6.0.0.21,6.0.0.20,6.0.0.19,6.0.0.18,6.0.0.17,6.0.0.16,6.0.0.15,6.0.0.14,6.0.0.13,6.0.0.12,6.0.0.11,6.0.0.10,6.0.0.9,6.0.0.8,6.0.0.7,6.0.0.6,6.0.0.5,6.0.0.4,6.0.0.3,6.0.0.2,6.0.0.1;;"
    #^Nuke
    if ran == 0:
        level_data = "V1;39;20;;3.3.0.9,4.1.0.10,2.0.0.11,3.1.0.12,2.0.1.13,5.0.2.3,5.0.2.4,5.0.2.5,5.0.2.6,5.0.2.7,5.0.4.3,5.0.4.4,5.0.5.5,5.0.5.6,5.0.5.7,3.0.6.11,4.1.6.14,4.1.6.15,5.0.7.5,5.0.7.6,5.0.7.7,3.3.7.9,4.3.7.10,2.0.7.11,5.0.7.12,1.0.7.13,3.1.7.14,5.0.8.5,3.3.8.10,4.3.8.11,5.0.8.12,2.0.8.13,3.1.8.14,5.0.9.3,5.0.9.4,5.0.9.5,5.0.9.6,5.0.9.7,3.3.9.10,4.3.9.11,5.0.9.12,1.0.9.13,3.1.9.14,3.3.10.9,4.3.10.10,2.0.10.11,5.0.10.12,1.0.10.13,3.1.10.14,3.3.11.10,4.3.11.11,5.0.11.12,2.0.11.13,3.1.11.14,3.3.12.10,4.3.12.11,5.0.12.12,1.0.12.13,3.1.12.14,3.3.13.9,4.3.13.10,1.0.13.11,5.0.13.12,2.0.13.13,3.1.13.14,3.2.14.11,4.1.14.14,4.1.14.15,3.0.16.11,4.1.16.14,4.1.16.15,5.0.17.0,5.0.17.1,5.0.17.2,5.0.17.3,5.0.17.4,3.3.17.9,4.3.17.10,2.0.17.11,5.0.17.12,1.0.17.13,3.1.17.14,3.3.18.9,4.3.18.10,1.0.18.11,5.0.18.12,2.0.18.13,3.1.18.14,5.0.19.0,5.0.19.1,3.2.19.11,4.1.19.14,4.1.19.15,5.0.20.2,5.0.20.3,5.0.20.4,3.0.21.11,4.1.21.14,4.1.21.15,5.0.22.2,5.0.22.3,5.0.22.4,3.3.22.6,5.0.22.7,5.0.22.8,5.0.22.9,4.3.22.10,2.0.22.11,5.0.22.12,1.0.22.13,3.1.22.14,5.0.23.2,3.3.23.6,5.0.23.7,1.3.23.8,5.0.23.9,4.3.23.10,1.0.23.11,5.0.23.12,2.0.23.13,3.1.23.14,5.0.24.0,5.0.24.1,5.0.24.2,5.0.24.3,5.0.24.4,3.2.24.11,4.1.24.14,4.1.24.15,5.0.26.5,5.0.26.6,5.0.26.7,5.0.26.8,5.0.26.9,3.3.26.11,5.0.26.12,1.0.26.13,4.0.26.14,2.0.26.15,3.3.27.11,5.0.27.12,1.0.27.13,4.0.27.14,2.0.27.15,5.0.28.5,5.0.28.6,3.3.28.11,5.0.28.12,1.0.28.13,4.0.28.14,2.0.28.15,5.0.29.7,5.0.29.8,5.0.29.9,3.3.29.11,5.0.29.12,1.0.29.13,4.0.29.14,2.0.29.15,3.3.30.11,5.0.30.12,1.0.30.13,4.0.30.14,2.0.30.15,5.0.31.5,5.0.31.6,5.0.31.7,5.0.31.8,5.0.31.9,3.3.31.11,5.0.31.12,1.0.31.13,4.0.31.14,2.0.31.15,3.3.32.11,5.0.32.12,1.0.32.13,4.0.32.14,2.0.32.15,5.0.33.5,5.0.33.6,5.0.33.7,5.0.33.8,5.0.33.9,3.3.33.11,5.0.33.12,1.0.33.13,4.0.33.14,2.0.33.15,5.0.34.5,5.0.34.9,3.3.34.11,5.0.34.12,1.0.34.13,4.0.34.14,2.0.34.15,5.0.35.5,5.0.35.6,5.0.35.7,5.0.35.8,5.0.35.9,3.3.35.11,5.0.35.12,1.0.35.13,4.3.35.14,2.0.35.15,5.0.34.16,2.0.34.17,3.1.34.18,2.1.38.19;;"
    #^Slow things
    if ran == 1:
        level_data = "V1;50;50;;2.0.16.18,2.0.22.18,1.0.11.21,0.0.12.22,1.0.21.22,1.0.11.23,2.0.21.24,4.0.12.19,1.2.8.21,1.2.8.23,3.0.11.22,3.1.16.19,3.0.22.19,8.0.12.23,8.0.13.21,8.0.14.21,7.0.14.24,7.0.13.24,1.0.17.22,2.0.17.24,5.0.17.21,4.0.17.20,4.0.19.20,0.1.19.21,0.3.19.22,4.0.19.24,3.0.23.21,3.0.23.24,3.0.24.20,5.1.24.21,3.0.25.22,5.1.24.24,3.0.24.25,5.0.25.20,2.0.25.21,2.0.25.24,5.0.25.25,4.0.26.20,5.0.26.21,3.0.26.22,3.0.26.23,5.0.26.24,4.0.26.25,3.3.27.19,1.0.27.20,5.0.27.21,5.0.27.22,5.0.27.23,5.0.27.24,2.0.27.25,3.1.27.26,5.0.28.20,4.0.28.21,4.0.28.22,4.0.28.23,4.0.28.24,5.0.28.25,2.0.29.20,1.0.29.21,2.0.29.22,1.0.29.23,2.0.29.24,1.0.29.25,4.0.30.19,3.2.30.20,3.2.30.21,3.2.30.22,3.2.30.23,3.2.30.24,3.2.30.25,4.0.30.26,4.0.31.19,4.0.31.26;;"
    #^C/4 sawtooth
    if ran == 2:
        level_data = "V1;50;50;;0.0.26.20,1.0.25.21,1.0.25.19,1.0.29.18,0.3.29.19,4.0.29.16,4.0.29.22,5.0.29.21,5.0.29.17,4.2.28.19,0.1.28.21,4.1.28.22,4.1.30.19,4.1.27.19,3.0.23.20,1.0.20.19,1.0.20.21;;"
    #^C/2 synth
    #level_data = "V1;99;99;;0.2.48.50,0.3.49.50,0.1.48.49,0.0.49.49,1.0.50.48,6.0.98.1,6.0.98.2,6.0.98.3,6.0.98.4,6.0.98.5,6.0.98.6,6.0.98.7,6.0.98.8,6.0.98.9,6.0.98.10,6.0.98.14,6.0.98.15,6.0.98.13,6.0.98.12,6.0.98.11,6.0.98.16,6.0.98.17,6.0.98.18,6.0.98.19,6.0.98.20,6.0.98.21,6.0.98.22,6.0.98.23,6.0.98.24,6.0.98.25,6.0.98.26,6.0.98.27,6.0.98.28,6.0.98.29,6.0.98.30,6.0.98.31,6.0.98.32,6.0.98.33,6.0.98.34,6.0.98.35,6.0.98.36,6.0.98.37,6.0.98.38,6.0.98.39,6.0.98.40,6.0.98.41,6.0.98.42,6.0.98.43,6.0.98.44,6.0.98.45,6.0.98.46,6.0.98.47,6.0.98.48,6.0.98.49,6.0.98.50,6.0.98.51,6.0.98.52,6.0.98.53,6.0.98.54,6.0.98.55,6.0.98.56,6.0.98.57,6.0.98.58,6.0.98.59,6.0.98.60,6.0.98.61,6.0.98.62,6.0.98.63,6.0.98.64,6.0.98.65,6.0.98.66,6.0.98.67,6.0.98.68,6.0.98.69,6.0.98.70,6.0.98.71,6.0.98.72,6.0.98.73,6.0.98.74,6.0.98.75,6.0.98.76,6.0.98.77,6.0.98.78,6.0.98.79,6.0.98.80,6.0.98.81,6.0.98.82,6.0.98.83,6.0.98.84,6.0.98.85,6.0.98.86,6.0.98.87,6.0.98.88,6.0.98.89,6.0.98.90,6.0.98.91,6.0.98.92,6.0.98.93,6.0.98.94,6.0.98.95,6.0.98.96,6.0.98.97,6.3.98.98,6.3.97.98,6.3.96.98,6.3.95.98,6.3.94.98,6.3.93.98,6.3.92.98,6.3.91.98,6.3.90.98,6.3.89.98,6.3.88.98,6.3.87.98,6.3.86.98,6.3.85.98,6.3.84.98,6.3.83.98,6.3.82.98,6.3.81.98,6.3.80.98,6.3.79.98,6.3.78.98,6.3.77.98,6.3.76.98,6.3.75.98,6.3.74.98,6.3.73.98,6.3.72.98,6.3.71.98,6.3.70.98,6.3.69.98,6.3.68.98,6.3.67.98,6.3.66.98,6.3.65.98,6.3.64.98,6.3.63.98,6.3.62.98,6.3.61.98,6.3.60.98,6.3.59.98,6.3.58.98,6.3.57.98,6.3.56.98,6.3.55.98,6.3.54.98,6.3.53.98,6.3.52.98,6.3.51.98,6.3.50.98,6.3.49.98,6.3.48.98,6.3.47.98,6.3.46.98,6.3.45.98,6.3.44.98,6.3.43.98,6.3.42.98,6.3.41.98,6.3.40.98,6.3.39.98,6.3.38.98,6.3.37.98,6.3.36.98,6.3.35.98,6.3.34.98,6.3.33.98,6.3.32.98,6.3.31.98,6.3.30.98,6.3.29.98,6.3.28.98,6.3.27.98,6.3.26.98,6.3.25.98,6.3.24.98,6.3.23.98,6.3.22.98,6.3.21.98,6.3.20.98,6.3.19.98,6.3.18.98,6.3.17.98,6.3.16.98,6.3.15.98,6.3.14.98,6.3.13.98,6.3.12.98,6.3.11.98,6.3.10.98,6.3.9.98,6.3.8.98,6.3.7.98,6.3.6.98,6.3.5.98,6.3.4.98,6.3.3.98,6.3.2.98,6.3.1.98,6.2.0.1,6.2.0.2,6.2.0.3,6.2.0.4,6.2.0.5,6.2.0.6,6.2.0.7,6.2.0.8,6.2.0.9,6.2.0.10,6.2.0.11,6.2.0.12,6.2.0.13,6.2.0.14,6.2.0.15,6.2.0.16,6.2.0.17,6.2.0.18,6.2.0.19,6.2.0.20,6.2.0.21,6.2.0.22,6.2.0.23,6.2.0.24,6.2.0.25,6.2.0.26,6.2.0.27,6.2.0.28,6.2.0.29,6.2.0.30,6.2.0.31,6.2.0.32,6.2.0.33,6.2.0.34,6.2.0.35,6.2.0.36,6.2.0.37,6.2.0.38,6.2.0.39,6.2.0.40,6.2.0.41,6.2.0.42,6.2.0.43,6.2.0.44,6.2.0.45,6.2.0.46,6.2.0.47,6.2.0.48,6.2.0.49,6.2.0.50,6.2.0.51,6.2.0.52,6.2.0.53,6.2.0.54,6.2.0.55,6.2.0.56,6.2.0.57,6.2.0.58,6.2.0.59,6.2.0.60,6.2.0.61,6.2.0.62,6.2.0.63,6.2.0.64,6.2.0.65,6.2.0.66,6.2.0.67,6.2.0.68,6.2.0.69,6.2.0.70,6.2.0.71,6.2.0.72,6.2.0.73,6.2.0.74,6.2.0.75,6.2.0.76,6.2.0.77,6.2.0.78,6.2.0.79,6.2.0.80,6.2.0.81,6.2.0.82,6.2.0.83,6.2.0.84,6.2.0.85,6.2.0.86,6.2.0.87,6.2.0.88,6.2.0.89,6.2.0.90,6.2.0.91,6.2.0.92,6.2.0.93,6.2.0.94,6.2.0.95,6.2.0.96,6.2.0.97,6.2.0.98,6.1.98.0,6.1.97.0,6.1.96.0,6.1.95.0,6.1.94.0,6.1.93.0,6.1.92.0,6.1.91.0,6.1.90.0,6.1.89.0,6.1.88.0,6.1.87.0,6.1.86.0,6.1.85.0,6.1.84.0,6.1.83.0,6.1.82.0,6.1.81.0,6.1.80.0,6.1.79.0,6.1.78.0,6.1.77.0,6.1.76.0,6.1.75.0,6.1.74.0,6.1.73.0,6.1.72.0,6.1.71.0,6.1.70.0,6.1.69.0,6.1.68.0,6.1.67.0,6.1.66.0,6.1.65.0,6.1.64.0,6.1.63.0,6.1.62.0,6.1.61.0,6.1.60.0,6.1.59.0,6.1.58.0,6.1.57.0,6.1.56.0,6.1.55.0,6.1.54.0,6.1.53.0,6.1.52.0,6.1.51.0,6.1.50.0,6.1.49.0,6.1.48.0,6.1.47.0,6.1.46.0,6.1.45.0,6.1.44.0,6.1.43.0,6.1.42.0,6.1.41.0,6.1.40.0,6.1.39.0,6.1.38.0,6.1.37.0,6.1.36.0,6.1.35.0,6.1.34.0,6.1.33.0,6.1.32.0,6.1.31.0,6.1.30.0,6.1.29.0,6.1.28.0,6.1.27.0,6.1.26.0,6.1.25.0,6.1.24.0,6.1.23.0,6.1.22.0,6.1.21.0,6.1.20.0,6.1.19.0,6.1.18.0,6.1.17.0,6.1.16.0,6.1.15.0,6.1.14.0,6.1.13.0,6.1.12.0,6.1.11.0,6.1.10.0,6.1.9.0,6.1.8.0,6.1.7.0,6.1.6.0,6.1.5.0,6.1.4.0,6.1.3.0,6.1.2.0,6.1.1.0,6.1.0.0;;"
    #^Bigger nuke
    #level_data = "V1;99;99;;0.0.1.1,0.0.2.2,0.0.3.3,0.0.4.4,0.0.5.5,0.0.6.6,0.0.7.7,0.0.8.8,0.0.9.9,0.0.10.10,0.0.11.11,0.0.12.12,0.0.13.13,0.0.14.14,0.0.15.15,0.0.16.16,0.0.17.17,0.0.18.18,0.0.19.19,0.0.20.20,0.0.21.21,0.0.22.22,0.0.23.23,0.0.24.24,0.0.25.25,0.0.26.26,0.0.27.27,0.0.28.28,0.0.29.29,0.0.30.30,0.0.31.31,0.0.32.32,0.0.33.33,0.0.34.34,0.0.35.35,0.0.36.36,0.0.37.37,0.0.38.38,0.0.39.39,0.0.40.40,0.0.41.41,0.0.42.42,0.0.43.43,0.0.44.44,0.0.45.45,0.0.46.46,0.0.47.47,0.0.48.48,0.0.49.49,0.0.50.50,0.0.51.51,0.0.52.52,0.0.53.53,0.0.54.54,0.0.55.55,0.0.56.56,0.0.57.57,0.0.58.58,0.0.59.59,0.0.60.60,0.0.61.61,0.0.62.62,0.0.63.63,0.0.64.64,0.0.65.65,0.0.66.66,0.0.67.67,0.0.68.68,0.0.69.69,0.0.70.70,0.0.71.71,0.0.72.72,0.0.73.73,0.0.74.74,0.0.75.75,0.0.76.76,0.0.77.77,0.0.78.78,0.0.79.79,0.0.80.80,0.0.81.81,0.0.82.82,0.0.83.83,0.0.84.84,0.0.85.85,0.0.86.86,0.0.87.87,0.0.88.88,0.0.89.89,0.0.90.90,0.0.91.91,0.0.92.92,0.0.93.93,0.0.94.94,0.0.95.95,0.0.96.96,0.0.97.97,0.0.98.98,0.0.0.0,1.0.43.44;;"
    #^Grid maker
    if ran == 3:
        level_data = "V1;50;50;;3.0.18.24,3.0.18.25,3.0.19.25,3.0.20.26,4.0.21.26,5.0.22.25,5.0.23.25,5.0.24.25,0.0.25.25,0.1.25.24,0.0.24.23,0.1.25.22,5.0.19.24,5.0.20.25,3.0.24.24,7.0.23.23,3.2.26.25,2.0.20.24,2.0.22.24,3.0.20.22,0.0.21.25,0.1.21.24,0.0.22.23,0.1.21.22,0.3.19.23,7.0.20.23,3.0.17.23,3.0.24.22,7.0.23.21;;"
    #^Enemy mover
    #level_data = "V1;10;10;;3.3.5.0,3.3.4.0,1.0.4.2,2.0.5.2,1.0.3.4,2.0.6.4,3.0.4.3,3.2.5.3,4.0.5.1,4.0.4.1;;"
    #^Small c/4 I made
    if ran == 4:
        level_data = "V1;20;7;;2.0.8.0,2.0.14.0,1.0.3.3,0.0.4.4,1.0.13.4,1.0.3.5,2.0.13.6,1.2.0.3,1.2.0.5,3.0.3.4,3.1.8.1,3.0.14.1,8.0.4.5,8.0.5.3,8.0.6.3,7.0.6.6,7.0.5.6,1.0.9.4,2.0.9.6,5.0.9.3,4.0.9.2,4.0.11.2,0.1.11.3,0.3.11.4,4.0.11.6,3.0.15.3,3.0.15.6,4.0.16.3,3.0.17.4,4.0.16.6,2.0.17.3,2.0.17.6,3.2.18.6,3.2.18.3,2.0.19.5,2.0.19.2;;"
    #^Better C/4 sawtooth
    #level_data = "V1;31;27;;3.0.0.4,3.0.4.6,3.0.4.7,3.0.5.5,5.0.5.6,5.0.5.7,5.0.6.5,2.0.6.6,2.0.6.7,4.0.7.5,4.0.7.6,4.0.7.7,2.0.8.5,5.0.8.6,4.0.8.7,5.3.21.16,5.3.21.18,5.3.21.20,5.3.21.22,3.3.22.22,3.3.23.15,1.3.23.24,3.3.24.8,2.3.24.22,3.3.25.1,1.3.28.26,2.3.29.24;;"
    #^Testing ground
    #level_data = "V1;5;5;;3.3.1.3,3.3.0.4,3.0.2.2,3.0.3.1,0.3.3.2,0.0.1.4,3.0.3.3,5.0.2.4;;"
    #^Diagonal mover
    #level_data = "V1;23;21;;2.1.0.5,2.1.0.17,2.1.1.5,2.1.1.17,3.0.12.9,3.0.12.10,3.0.12.11,3.0.12.12,3.0.12.13,3.0.12.14,3.0.12.15,3.0.12.16,3.0.12.17,3.0.12.18,3.0.12.19,3.0.12.20,5.0.13.9,5.0.13.10,5.0.13.11,5.0.13.12,5.0.13.13,5.0.13.14,5.0.13.15,5.0.13.16,5.0.13.17,5.0.13.18,5.0.13.19,5.0.13.20,2.0.14.9,2.0.14.10,2.0.14.11,2.0.14.12,2.0.14.13,2.0.14.14,2.0.14.15,2.0.14.16,2.0.14.17,2.0.14.18,2.0.14.19,2.0.14.20,4.2.15.9,4.1.15.10,4.1.15.11,4.1.15.12,4.1.15.13,4.1.15.14,4.3.15.15,4.3.15.16,4.3.15.17,4.1.15.18,4.3.15.19,4.3.15.20,1.0.16.9,1.0.16.10,1.0.16.11,1.0.16.12,1.0.16.13,1.0.16.14,1.0.16.15,1.0.16.16,1.0.16.17,1.0.16.18,1.0.16.19,1.0.16.20,5.0.17.10,5.0.17.12,2.0.18.10,5.0.18.12,3.2.19.10,2.0.19.12,2.1.20.5,3.1.20.10,2.1.21.7,0.0.2.6,0.3.3.5,8.0.3.7,5.3.3.4,7.0.5.8,7.0.4.8,8.0.4.5,8.0.5.5,4.1.7.6,0.0.2.9,1.0.3.10,1.0.6.10,1.0.7.4,8.0.5.4,3.2.4.3,4.3.3.3,0.0.5.3,2.0.2.2,2.0.2.1,8.0.7.3,4.0.8.6,0.1.8.8,0.1.8.9,1.0.10.6,2.0.12.1,5.3.6.6,5.3.5.6,5.3.4.6,5.3.3.6,3.3.1.12,3.1.0.10,2.0.10.8;;"
    #^Different C/12 sawtooth, doesn't work but is interesting
    #level_data = "V1;7;9;;2.2.0.0,2.2.0.1,1.2.0.7,1.2.0.8,0.3.1.2,0.1.1.6,3.3.1.8,3.0.2.0,3.1.2.7,2.2.3.0,2.2.3.1,2.2.3.2,3.2.3.4,3.2.3.5,1.2.3.7,1.2.3.8,3.1.4.1,0.3.4.3,0.1.4.6,3.3.4.8,2.2.6.1,2.2.6.2,1.2.6.7,1.2.6.8;;"
    #^printer test
    #level_data = "V1;27;20;;4.3.5.6,0.0.5.7,4.0.6.6,4.0.7.6,5.0.18.8,5.0.18.9,5.0.18.10,5.0.18.11,5.0.18.12,5.0.18.13,5.0.18.14,5.0.18.15,5.0.18.16,5.0.18.17,5.0.18.18,5.0.18.19,2.0.19.8,2.0.19.9,2.0.19.10,2.0.19.11,2.0.19.12,2.0.19.13,2.0.19.14,2.0.19.15,2.0.19.16,2.0.19.17,2.0.19.18,2.0.19.19,4.1.20.9,4.1.20.11,1.0.21.9,1.0.21.11,5.1.22.11,4.2.8.6,1.0.10.4,8.0.10.3,8.0.8.4,8.0.8.5,4.1.6.3,0.0.8.3,3.2.7.3,3.1.6.7,3.1.7.7,3.1.8.7,5.2.10.6,5.0.9.6,1.0.4.4,1.0.3.4,1.2.4.16,1.2.3.16,1.0.11.5,8.0.11.7,0.1.12.7,0.1.13.7,0.1.14.7,5.1.14.8,5.1.13.8,5.1.12.8,5.1.12.5,4.2.12.4,4.2.13.5,3.2.18.6,5.2.14.5,4.2.14.4,1.2.16.5,2.2.16.7,3.0.17.8,3.0.17.9,3.0.17.10,3.0.17.11,3.0.17.12,3.0.17.13,3.0.17.14,3.0.17.15,3.0.17.16,3.0.17.17,3.0.17.18,3.0.17.19,1.0.21.19,1.0.21.18,1.0.21.17,1.0.21.16,1.0.21.15,1.0.21.14,1.0.21.13,1.0.21.12,1.0.21.10,1.0.21.8,4.0.20.8,4.1.20.10,4.1.20.12,4.1.20.13,4.1.20.14,4.1.20.15,4.1.20.16,4.1.20.17,4.1.20.18,4.1.20.19,5.1.22.9,5.1.23.11,2.0.24.11,2.0.23.9,2.0.26.6,2.0.25.4,3.2.24.9,3.1.25.9,0.2.2.7,2.2.1.8,2.2.0.7,2.2.1.0,2.2.17.0,3.1.4.10,3.3.3.10,8.3.0.2;;"
    #^Massive C/12 sawtooth, but IT WORKS!!!
    #level_data = "V3;44;u;{(0(kp)E)fv(0(7N)?(49(49)qG0{g(40(3?)22{{{g{2{I{I)la4(48(3Y)g{{2sIK{C(89(3+)!88IaK)c7G(88(3X)E{A{{0ooo{{giii(sq(3%)(3!)bsss{{6a482(oy(3})6a4q2s4Go(3$(3T)Y(3U)d6a4q(87(46)s(sq(3Z)(87(4j)(43(b-)C(Iv)d(gf(g2)(0(kc);;"
    #^V3 version of it on a large grid, for later use
    #level_data = "V1;27;20;;8.3.0.2,2.2.0.7,2.2.1.0,2.2.1.8,0.2.2.7,1.0.3.4,3.3.3.10,1.2.3.16,1.0.4.4,3.1.4.10,1.2.4.16,4.3.5.6,0.0.5.7,4.1.6.3,4.0.6.6,3.2.7.3,4.0.7.6,0.0.8.3,8.0.8.4,8.0.8.5,4.2.8.6,8.0.10.3,1.0.10.4,1.0.11.5,8.0.11.7,4.2.12.4,5.1.12.5,0.1.12.7,5.1.12.8,4.2.13.5,0.1.13.7,5.1.13.8,4.0.14.5,0.1.14.7,5.1.14.8,1.2.16.5,2.2.16.7,2.2.17.0,3.0.17.8,3.0.17.9,3.0.17.10,3.0.17.11,3.0.17.12,3.0.17.13,3.0.17.14,3.0.17.15,3.0.17.16,3.0.17.17,3.0.17.18,3.0.17.19,5.0.18.8,5.0.18.9,5.0.18.10,5.0.18.11,5.0.18.12,5.0.18.13,5.0.18.14,5.0.18.15,5.0.18.16,5.0.18.17,5.0.18.18,5.0.18.19,2.0.19.8,2.0.19.9,2.0.19.10,2.0.19.11,2.0.19.12,2.0.19.13,2.0.19.14,2.0.19.15,2.0.19.16,2.0.19.17,2.0.19.18,2.0.19.19,4.0.20.8,4.1.20.9,4.1.20.10,4.1.20.11,4.1.20.12,4.1.20.13,4.1.20.14,4.1.20.15,4.1.20.16,4.1.20.17,4.1.20.18,4.1.20.19,1.0.21.8,1.0.21.9,1.0.21.10,1.0.21.11,1.0.21.12,1.0.21.13,1.0.21.14,1.0.21.15,1.0.21.16,1.0.21.17,1.0.21.18,1.0.21.19,5.1.22.9,5.1.22.11,2.0.23.9,5.1.23.11,3.2.24.9,2.0.24.11,2.0.25.4,3.1.25.9,2.0.26.6;;"
    #^I removed some things from it
    #level_data = "V1;67;55;;5.0.0.16,5.0.0.17,5.0.0.18,5.0.0.19,5.0.0.20,5.0.0.21,5.0.0.22,5.0.0.23,5.0.2.23,5.0.4.22,5.0.4.23,5.0.6.23,5.0.8.20,5.0.8.21,5.0.8.22,5.0.8.23,5.0.10.23,5.0.12.22,5.0.12.23,5.0.14.23,5.0.16.16,5.0.16.17,5.0.16.18,5.0.16.19,5.0.16.20,5.0.16.21,5.0.16.22,5.0.16.23,5.0.18.23,5.0.20.22,5.0.20.23,5.0.22.23,5.0.24.20,5.0.24.21,5.0.24.22,5.0.24.23,5.0.26.23,5.0.28.22,5.0.28.23,3.2.29.25,3.2.29.26,3.2.29.27,3.2.29.28,3.2.29.29,5.0.30.23,3.2.30.27,3.2.30.29,3.2.31.27,3.2.31.28,3.2.31.29,5.0.32.16,5.0.32.17,5.0.32.18,5.0.32.19,5.0.32.20,5.0.32.21,5.0.32.22,5.0.32.23,3.2.33.25,3.2.33.27,3.2.33.28,3.2.33.29,5.0.34.23,3.2.34.25,3.2.34.27,3.2.35.25,3.2.35.26,3.2.35.27,3.2.35.28,3.2.35.29,5.0.36.22,5.0.36.23,3.2.37.25,3.2.37.26,3.2.37.27,3.2.37.28,3.2.37.29,5.0.38.23,3.2.38.25,5.0.40.20,5.0.40.21,5.0.40.22,5.0.40.23,3.2.40.25,3.2.40.26,3.2.40.27,3.2.40.28,3.2.40.29,3.2.41.25,5.0.42.23,5.0.43.31,5.0.43.39,5.0.43.47,5.1.44.7,5.1.44.15,5.0.44.22,5.0.44.23,3.2.44.25,3.2.44.26,3.2.44.27,3.2.44.28,3.2.44.29,5.0.44.31,5.0.44.39,5.0.44.47,5.1.45.7,5.1.45.15,7.0.45.23,3.2.45.28,5.0.45.31,5.1.45.33,5.0.45.35,5.0.45.37,5.0.45.39,5.0.45.41,5.0.45.43,5.0.45.45,5.0.45.47,5.0.45.49,5.0.45.51,5.0.45.53,5.1.46.1,5.1.46.3,5.1.46.5,5.1.46.7,5.1.46.9,5.1.46.11,5.1.46.13,5.1.46.15,5.1.46.17,5.1.46.19,5.1.46.21,5.0.46.23,3.2.46.27,2.0.47.0,2.0.47.23,3.2.47.28,1.0.47.31,1.0.47.54,3.1.48.9,3.1.48.13,3.1.48.15,3.1.48.19,3.2.48.23,0.3.48.24,3.2.48.26,3.2.48.27,3.2.48.28,3.2.48.29,0.1.48.30,3.3.48.42,3.3.48.44,3.3.48.46,3.3.48.48,3.3.48.50,3.3.49.2,3.3.49.8,3.3.49.10,3.3.49.12,3.3.49.14,3.3.49.16,3.3.49.18,3.3.49.20,3.3.49.22,3.1.49.33,3.1.49.37,3.1.49.49,3.1.49.51,3.1.49.53,2.0.50.0,2.0.50.23,3.2.50.26,3.2.50.27,3.2.50.28,3.2.50.29,1.0.50.31,1.0.50.54,2.0.51.0,2.0.51.23,3.2.51.27,1.0.51.31,1.0.51.54,3.1.52.0,3.1.52.4,3.1.52.6,3.1.52.8,3.1.52.12,0.3.52.24,3.2.52.26,3.2.52.27,3.2.52.28,0.1.52.30,3.2.52.31,3.3.52.33,3.3.52.35,3.3.52.39,3.3.52.43,3.3.52.53,3.3.53.5,3.3.53.7,3.3.53.9,3.3.53.21,3.1.53.32,3.1.53.34,3.1.53.36,3.1.53.38,3.1.53.40,3.1.53.42,3.1.53.48,2.0.54.0,2.0.54.23,8.0.54.25,3.2.54.26,3.2.54.27,3.2.54.28,8.0.54.29,1.0.54.31,1.0.54.54,2.0.55.1,2.0.55.24,1.0.55.30,1.0.55.53,3.1.56.8,3.1.56.12,3.1.56.16,3.1.56.18,3.1.56.20,3.1.56.22,0.3.56.25,0.1.56.29,3.3.56.39,3.3.56.41,3.3.56.49,3.3.56.51,3.3.56.53,3.3.57.17,3.3.57.19,3.3.57.21,3.3.57.23,3.1.57.38,3.1.57.40,3.1.57.42,3.1.57.50,3.1.57.52,2.0.58.1,2.0.58.24,3.2.58.27,3.2.58.28,1.0.58.30,1.0.58.53,2.0.59.1,2.0.59.24,3.2.59.27,1.0.59.30,1.0.59.53,3.1.60.1,0.3.60.25,3.2.60.27,0.1.60.29,3.2.60.30,3.3.60.32,3.3.60.36,3.3.60.38,3.3.60.40,3.3.60.42,3.3.60.46,3.3.60.50,3.3.61.2,3.3.61.8,3.3.61.16,3.3.61.18,3.1.61.33,2.0.62.1,2.0.62.24,8.0.62.26,3.2.62.27,8.0.62.28,1.0.62.30,1.0.62.53,2.0.63.2,2.0.63.25,1.0.63.29,1.0.63.52,3.1.64.5,3.1.64.7,3.1.64.9,3.1.64.11,3.1.64.13,3.1.64.15,3.1.64.19,3.1.64.21,3.1.64.23,3.2.64.25,0.3.64.26,0.1.64.28,3.3.64.34,3.3.64.42,3.0.65.2,3.3.65.8,3.3.65.12,3.3.65.20,3.3.65.24,3.1.65.31,3.1.65.33,3.1.65.35,3.1.65.41,3.1.65.43,3.1.65.45,3.1.65.47,3.1.65.49,2.0.66.2,2.0.66.25,8.0.66.27,1.0.66.29,1.0.66.52;;"
    #^Printer "Pyll Machine"
    #level_data = "V1;38;55;;3.2.0.25,3.2.0.26,3.2.0.27,3.2.0.28,3.2.0.29,3.2.1.27,3.2.1.29,3.2.2.27,3.2.2.28,3.2.2.29,3.2.4.25,3.2.4.27,3.2.4.28,3.2.4.29,3.2.5.25,3.2.5.27,3.2.6.25,3.2.6.26,3.2.6.27,3.2.6.28,3.2.6.29,3.2.8.25,3.2.8.26,3.2.8.27,3.2.8.28,3.2.8.29,3.2.9.25,3.2.11.25,3.2.11.26,3.2.11.27,3.2.11.28,3.2.11.29,3.2.12.25,3.2.15.25,3.2.15.26,3.2.15.27,3.2.15.28,3.2.15.29,3.2.16.28,3.2.17.27,2.0.18.0,2.0.18.23,3.2.18.28,1.0.18.31,1.0.18.54,3.1.19.9,3.1.19.13,3.1.19.15,3.1.19.19,3.2.19.23,0.3.19.24,3.2.19.26,3.2.19.27,3.2.19.28,3.2.19.29,0.1.19.30,3.3.19.42,3.3.19.44,3.3.19.46,3.3.19.48,3.3.19.50,3.3.20.2,3.3.20.8,3.3.20.10,3.3.20.12,3.3.20.14,3.3.20.16,3.3.20.18,3.3.20.20,3.3.20.22,3.1.20.33,3.1.20.37,3.1.20.49,3.1.20.51,3.1.20.53,2.0.21.0,2.0.21.23,3.2.21.26,3.2.21.27,3.2.21.28,3.2.21.29,1.0.21.31,1.0.21.54,2.0.22.0,2.0.22.23,3.2.22.27,1.0.22.31,1.0.22.54,3.1.23.0,3.1.23.4,3.1.23.6,3.1.23.8,3.1.23.12,0.3.23.24,3.2.23.26,3.2.23.27,3.2.23.28,0.1.23.30,3.2.23.31,3.3.23.33,3.3.23.35,3.3.23.39,3.3.23.43,3.3.23.53,3.3.24.5,3.3.24.7,3.3.24.9,3.3.24.21,3.1.24.32,3.1.24.34,3.1.24.36,3.1.24.38,3.1.24.40,3.1.24.42,3.1.24.48,2.0.25.0,2.0.25.23,3.2.25.26,3.2.25.27,3.2.25.28,1.0.25.31,1.0.25.54,2.0.26.1,2.0.26.24,1.0.26.30,1.0.26.53,3.1.27.8,3.1.27.12,3.1.27.16,3.1.27.18,3.1.27.20,3.1.27.22,0.3.27.25,0.1.27.29,3.3.27.39,3.3.27.41,3.3.27.49,3.3.27.51,3.3.27.53,3.3.28.17,3.3.28.19,3.3.28.21,3.3.28.23,3.1.28.38,3.1.28.40,3.1.28.42,3.1.28.50,3.1.28.52,2.0.29.1,2.0.29.24,3.2.29.27,3.2.29.28,1.0.29.30,1.0.29.53,2.0.30.1,2.0.30.24,3.2.30.27,1.0.30.30,1.0.30.53,3.1.31.1,0.3.31.25,3.2.31.27,0.1.31.29,3.2.31.30,3.3.31.32,3.3.31.36,3.3.31.38,3.3.31.40,3.3.31.42,3.3.31.46,3.3.31.50,3.3.32.2,3.3.32.8,3.3.32.16,3.3.32.18,3.1.32.33,2.0.33.1,2.0.33.24,3.2.33.27,1.0.33.30,1.0.33.53,2.0.34.2,2.0.34.25,1.0.34.29,1.0.34.52,3.1.35.5,3.1.35.7,3.1.35.9,3.1.35.11,3.1.35.13,3.1.35.15,3.1.35.19,3.1.35.21,3.1.35.23,3.2.35.25,0.3.35.26,0.1.35.28,3.3.35.34,3.3.35.42,3.0.36.2,3.3.36.8,3.3.36.12,3.3.36.20,3.3.36.24,3.1.36.31,3.1.36.33,3.1.36.35,3.1.36.41,3.1.36.43,3.1.36.45,3.1.36.47,3.1.36.49,2.0.37.2,2.0.37.25,1.0.37.29,1.0.37.52;;"
    #^Printer with some bits trimmed
    #level_data = "V1;67;55;;3.2.29.25,3.2.29.26,3.2.29.27,3.2.29.28,3.2.29.29,3.2.30.27,3.2.30.29,3.2.31.27,3.2.31.28,3.2.31.29,3.2.33.25,3.2.33.27,3.2.33.28,3.2.33.29,3.2.34.25,3.2.34.27,3.2.35.25,3.2.35.26,3.2.35.27,3.2.35.28,3.2.35.29,3.2.37.25,3.2.37.26,3.2.37.27,3.2.37.28,3.2.37.29,3.2.38.25,3.2.40.25,3.2.40.26,3.2.40.27,3.2.40.28,3.2.40.29,3.2.41.25,3.2.44.25,3.2.44.26,3.2.44.27,3.2.44.28,3.2.44.29,3.2.45.28,3.2.46.27,2.0.47.0,2.0.47.23,3.2.47.28,1.0.47.31,1.0.47.54,3.1.48.9,3.1.48.13,3.1.48.15,3.1.48.19,3.2.48.23,0.3.48.24,3.2.48.26,3.2.48.27,3.2.48.28,3.2.48.29,0.1.48.30,3.3.48.42,3.3.48.44,3.3.48.46,3.3.48.48,3.3.48.50,3.3.49.2,3.3.49.8,3.3.49.10,3.3.49.12,3.3.49.14,3.3.49.16,3.3.49.18,3.3.49.20,3.3.49.22,3.1.49.33,3.1.49.37,3.1.49.49,3.1.49.51,3.1.49.53,2.0.50.0,2.0.50.23,3.2.50.26,3.2.50.27,3.2.50.28,3.2.50.29,1.0.50.31,1.0.50.54,2.0.51.0,2.0.51.23,3.2.51.27,1.0.51.31,1.0.51.54,3.1.52.0,3.1.52.4,3.1.52.6,3.1.52.8,3.1.52.12,0.3.52.24,3.2.52.26,3.2.52.27,3.2.52.28,0.1.52.30,3.2.52.31,3.3.52.33,3.3.52.35,3.3.52.39,3.3.52.43,3.3.52.53,3.3.53.5,3.3.53.7,3.3.53.9,3.3.53.21,3.1.53.32,3.1.53.34,3.1.53.36,3.1.53.38,3.1.53.40,3.1.53.42,3.1.53.48,2.0.54.0,2.0.54.23,3.2.54.26,3.2.54.27,3.2.54.28,1.0.54.31,1.0.54.54,2.0.55.1,2.0.55.24,1.0.55.30,1.0.55.53,3.1.56.8,3.1.56.12,3.1.56.16,3.1.56.18,3.1.56.20,3.1.56.22,0.3.56.25,0.1.56.29,3.3.56.39,3.3.56.41,3.3.56.49,3.3.56.51,3.3.56.53,3.3.57.17,3.3.57.19,3.3.57.21,3.3.57.23,3.1.57.38,3.1.57.40,3.1.57.42,3.1.57.50,3.1.57.52,2.0.58.1,2.0.58.24,3.2.58.27,3.2.58.28,1.0.58.30,1.0.58.53,2.0.59.1,2.0.59.24,3.2.59.27,1.0.59.30,1.0.59.53,3.1.60.1,0.3.60.25,3.2.60.27,0.1.60.29,3.2.60.30,3.3.60.32,3.3.60.36,3.3.60.38,3.3.60.40,3.3.60.42,3.3.60.46,3.3.60.50,3.3.61.2,3.3.61.8,3.3.61.16,3.3.61.18,3.1.61.33,2.0.62.1,2.0.62.24,3.2.62.27,1.0.62.30,1.0.62.53,2.0.63.2,2.0.63.25,1.0.63.29,1.0.63.52,3.1.64.5,3.1.64.7,3.1.64.9,3.1.64.11,3.1.64.13,3.1.64.15,3.1.64.19,3.1.64.21,3.1.64.23,3.2.64.25,0.3.64.26,0.1.64.28,3.3.64.34,3.3.64.42,3.0.65.2,3.3.65.8,3.3.65.12,3.3.65.20,3.3.65.24,3.1.65.31,3.1.65.33,3.1.65.35,3.1.65.41,3.1.65.43,3.1.65.45,3.1.65.47,3.1.65.49,2.0.66.2,2.0.66.25,1.0.66.29,1.0.66.52,8.0.0.29,8.0.0.28,8.0.0.27,8.0.0.26,8.0.0.25;;"
    #^Printer with end bits
    if ran == 4 or ran == 5:
        level_data = "V3;1q;11;{)0{a)04(13)}(0(1Q)(2P(2P)(5t(2P)(85(2Q)(0(2S)4{{44o)64(1x(2I)Y)bd4{6(2$(1r)(0(1b)o(1q(1q)(47)b(1B(1e)(2P(2N)Y(1d)6o(1x)8(8n)c(3}(12)(2P(1p)(9J(2N)(5t)c(2-(1d)(2z)g(5t(2A)(2P(1y)(9F)g(kr(1n)(2P(2v)(9p)g(5t(11)44)36(1h)i(2T)}4{644G(qW)9(hx)b(2P(11)S)37(1h)ng(1c)TG)0d{G(2Y)6G(4e)6(2P(1a)(2Y)g(5I)7(1x)8(2P)V(2T)6{)26)h8(1x)g(5O)6(1p)Y)54G(1i)9G)f7(4g)8(1x)8(5t)Z)36(1p)b)15(5G)7(5O)a(2P)Y(2v)9(1p)8(4g)6(2P)7)k6i(2P)+(43)l(1h)8i{{2)25(0(15)(1h)b2G(1l(19){(1h)k(za(1l)(km(1f)o(1h)b(sA)d(pS(1g)(2T(1e)(1d)d(5t(2D)(Ao(1v)(6$)c(5t(1d)(x%(1n)(2P(1p)(6P)d(5J(19)Y(2P)f(aX(2A)(J.(1F)(2P(1n)(2$(1v)(87(1i)(2z(1p)(aX(1n)(n5)g(kf(2s)(1x)i(v5(1b)(3=)72Y{2(1l(1c)(v5)7(1h(1d)(0(4a)(19V(2R)(1kH(5s)(1p})q;;"
    #^Printer with an adition by BlockOG

    #level_data = "V1;27;27;;2.0.0.0,8.3.0.1,2.2.0.6,2.2.1.7,0.2.2.6,1.0.3.3,3.3.3.8,1.0.3.23,1.0.4.3,3.1.4.18,1.0.4.23,4.3.5.5,0.0.5.6,4.1.6.2,4.0.6.5,3.2.7.2,4.0.7.5,0.0.8.2,8.0.8.3,8.0.8.4,4.2.8.5,8.0.10.2,1.0.10.3,0.1.12.6,5.1.12.7,4.2.13.4,1.2.16.4,2.2.16.6,3.0.17.7,3.0.17.8,3.0.17.9,3.0.17.10,3.0.17.11,3.0.17.12,3.0.17.13,3.0.17.14,3.0.17.15,3.0.17.16,3.0.17.17,3.0.17.18,3.0.17.19,3.0.17.20,3.0.17.21,3.0.17.22,3.0.17.23,3.0.17.24,3.0.17.25,3.0.17.26,2.0.18.0,5.0.18.7,5.0.18.8,5.0.18.9,5.0.18.10,5.0.18.11,5.0.18.12,5.0.18.13,5.0.18.14,5.0.18.15,5.0.18.16,5.0.18.17,5.0.18.18,5.0.18.19,5.0.18.20,5.0.18.21,5.0.18.22,5.0.18.23,5.0.18.24,5.0.18.25,5.0.18.26,2.0.19.7,2.0.19.8,2.0.19.9,2.0.19.10,2.0.19.11,2.0.19.12,2.0.19.13,2.0.19.14,2.0.19.15,2.0.19.16,2.0.19.17,2.0.19.18,2.0.19.19,2.0.19.20,2.0.19.21,2.0.19.22,2.0.19.23,2.0.19.24,2.0.19.25,2.0.19.26,4.0.20.7,4.1.20.8,4.1.20.9,4.1.20.10,4.1.20.11,4.1.20.12,4.1.20.13,4.1.20.14,4.1.20.15,4.1.20.16,4.1.20.17,4.1.20.18,4.1.20.19,4.1.20.20,4.1.20.21,4.1.20.22,4.1.20.23,4.1.20.24,4.1.20.25,4.1.20.26,1.0.21.7,1.0.21.8,1.0.21.9,1.0.21.10,1.0.21.11,1.0.21.12,1.0.21.13,1.0.21.14,1.0.21.15,1.0.21.16,1.0.21.17,1.0.21.18,1.0.21.19,1.0.21.20,1.0.21.21,1.0.21.22,1.0.21.23,1.0.21.24,1.0.21.25,1.0.21.26,5.2.22.12,5.2.22.14,2.0.23.12,5.2.23.14,3.2.24.12,2.0.24.14,2.0.25.3,3.1.25.12,2.0.26.5,0.1.13.6,5.1.13.7,2.0.10.6,8.0.10.4,4.0.12.4,1.0.9.7;;"
    #^ C/20 sawtooth, using the same design as the C/12 proving that it's infinitly expandable
    if ran == 6:
        level_data = "V1;24;27;;1.0.0.9,4.1.0.10,2.0.1.1,2.2.1.10,8.0.2.0,0.2.3.10,4.1.4.2,1.0.4.4,3.3.4.9,1.0.4.24,3.2.5.2,1.0.5.4,3.1.5.19,1.0.5.24,0.0.6.2,8.0.6.3,4.1.6.5,0.0.6.6,8.0.7.0,1.0.7.7,8.0.8.2,1.0.8.3,8.0.8.4,2.0.8.6,4.0.10.4,0.1.10.6,5.1.10.7,4.2.11.4,0.1.11.6,5.1.11.7,1.2.13.4,2.2.13.6,2.0.14.0,3.0.14.7,3.0.14.8,3.0.14.9,3.0.14.10,3.0.14.11,3.0.14.12,3.0.14.13,3.0.14.14,3.0.14.15,3.0.14.16,3.0.14.17,3.0.14.18,3.0.14.19,3.0.14.20,3.0.14.21,3.0.14.22,3.0.14.23,3.0.14.24,3.0.14.25,3.0.14.26,5.0.15.7,5.0.15.8,5.0.15.9,5.0.15.10,5.0.15.11,5.0.15.12,5.0.15.13,5.0.15.14,5.0.15.15,5.0.15.16,5.0.15.17,5.0.15.18,5.0.15.19,5.0.15.20,5.0.15.21,5.0.15.22,5.0.15.23,5.0.15.24,5.0.15.25,5.0.15.26,2.0.16.7,2.0.16.8,2.0.16.9,2.0.16.10,2.0.16.11,2.0.16.12,2.0.16.13,2.0.16.14,2.0.16.15,2.0.16.16,2.0.16.17,2.0.16.18,2.0.16.19,2.0.16.20,2.0.16.21,2.0.16.22,2.0.16.23,2.0.16.24,2.0.16.25,2.0.16.26,4.0.17.7,4.1.17.8,4.1.17.9,4.1.17.10,4.1.17.11,4.1.17.12,4.1.17.13,4.1.17.14,4.1.17.15,4.1.17.16,4.1.17.17,4.1.17.18,4.1.17.19,4.1.17.20,4.1.17.21,4.1.17.22,4.1.17.23,4.1.17.24,4.1.17.25,4.1.17.26,1.0.18.7,1.0.18.8,1.0.18.9,1.0.18.10,1.0.18.11,1.0.18.12,1.0.18.13,1.0.18.14,1.0.18.15,1.0.18.16,1.0.18.17,1.0.18.18,1.0.18.19,1.0.18.20,1.0.18.21,1.0.18.22,1.0.18.23,1.0.18.24,1.0.18.25,1.0.18.26,5.2.19.12,5.2.19.14,2.0.20.12,5.2.20.14,3.2.21.12,2.0.21.14,2.0.22.3,3.1.22.12,2.0.23.5;;"
    #^ optimised C/20 sawtooth

    #level_data = "V1;50;50;;3.0.9.4,1.0.11.3,1.0.11.5,0.0.12.4,4.1.13.3,4.2.14.3,0.1.14.5,4.1.14.6,4.0.15.0,5.0.15.1,1.0.15.2,0.3.15.3,5.0.15.5,4.0.15.6,4.1.16.3,5.0.11.7,5.0.9.7,5.0.7.7,5.0.11.8,5.0.11.9,5.0.7.8,5.0.5.7,5.0.3.7,5.0.1.7,5.0.3.9,5.0.3.8,1.0.0.5,1.0.0.3,4.2.20.8,0.0.20.9,4.3.20.10,4.0.20.11,0.2.22.10,5.2.22.9,4.2.23.10,4.3.23.9,1.3.20.13,1.3.22.13,0.1.21.12,5.1.18.13,5.1.17.13,5.1.16.13,5.1.18.15,5.1.18.17,5.1.17.17,5.1.18.19,5.1.18.21,5.1.17.21,5.1.16.21,5.1.18.23,1.3.20.24,1.3.22.24,3.1.21.15,8.1.22.6,1.1.22.7,2.1.19.7,2.1.19.6,4.1.17.9,5.1.18.9,1.1.19.9;;"
    #^doesn't work
    if ran == 7:
        level_data = "V3;2c;w;{(0(lW)6822(4o(4l)Y(2e(2e)o(c?(6u)(8J(2f)(8N(6v)Y{6)19(nQ(21)sa)08(n!(4m)(0(jf);;"
    #^ship pong
    if ran == 8:
        level_data = "V1;15;19;;3.0.0.11,3.0.0.12,3.0.0.13,3.0.0.14,3.0.0.15,3.0.0.16,3.0.0.17,3.0.0.18,2.1.2.18,2.1.2.17,2.1.2.16,2.1.2.15,2.1.2.14,2.1.2.13,2.1.2.12,2.1.2.11,1.1.4.11,1.1.4.12,1.1.4.13,1.1.4.16,1.1.4.15,1.1.4.17,1.1.4.18,1.1.4.14,5.1.1.18,5.1.1.17,5.1.1.16,5.1.1.15,5.1.1.14,5.1.1.13,5.1.1.12,5.1.1.11,4.0.3.11,4.1.3.12,4.1.3.13,4.1.3.14,4.1.3.15,4.1.3.16,4.1.3.17,4.1.3.18,5.1.5.14,5.1.5.13,5.1.6.14,5.1.7.14,2.3.6.13,2.3.8.14,2.1.8.10,2.1.10.11,3.2.7.13,3.1.9.13,5.1.10.10,5.1.9.10,5.1.11.11,2.1.11.10,3.2.13.11,3.0.12.11,5.0.12.10,5.0.13.10,0.1.14.10,2.1.13.0,1.1.14.2;;"
    #^large cordship
    if ran == 9:
        level_data = "V3;16;16;{(0(O^)2(14(29)(0(2i)4{{6)55(0(24)o(26(26)Y(4n)6)59(8L)&2{{{S(2b(10)(10(11))0^cc)ede(16)&g(1i)c(c{)-(15)7)}4(e2)=(15)62{{G{{0(15)}(ge(10)(4n)d(9H)-(15)c(2b(16)(8L(17)i(im(16)4(1a(18)(7Q)6(m!(2b)(jB(27)(4h)6(4n(22)Y(uj(2b)(vq(36);;"
    #^Wave Machine made by The Trash Cell on YouTube

    if ran == 10:
        level_data = "V1;87;27;;3.0.6.11,3.0.6.12,3.0.6.13,3.0.6.14,3.0.6.15,3.0.6.16,3.0.6.17,3.0.6.18,3.0.6.19,3.0.6.20,2.0.8.11,2.0.8.12,2.0.8.13,2.0.8.14,2.0.8.15,2.0.8.16,2.0.8.17,2.0.8.20,2.0.8.19,2.0.8.18,1.0.10.20,1.0.10.19,1.0.10.18,1.0.10.12,1.0.10.11,1.0.10.13,1.0.10.14,1.0.10.15,1.0.10.16,1.0.10.17,4.1.9.20,4.1.9.19,4.1.9.18,4.1.9.17,4.1.9.16,4.1.9.15,4.1.9.14,4.1.9.13,4.1.9.12,4.0.9.11,5.0.7.20,5.0.7.19,5.0.7.18,5.0.7.17,5.0.7.16,5.0.7.15,5.0.7.14,5.0.7.13,5.0.7.12,5.0.7.11,2.1.11.18,2.1.13.14,5.1.14.14,2.0.19.14,2.1.15.14,5.1.18.14,5.1.17.14,5.1.16.14,2.1.16.9,2.1.17.9,2.1.20.9,1.1.17.11,5.1.18.9,5.1.19.9,3.1.12.17,3.1.15.11,3.0.19.10,5.0.0.26,5.0.86.0;;"
    #cord 2

    #level_data = "V1;27;20;;4.3.5.6,0.0.5.7,4.0.6.6,4.0.7.6,5.0.18.8,5.0.18.9,5.0.18.10,5.0.18.11,5.0.18.12,5.0.18.13,5.0.18.14,5.0.18.15,5.0.18.16,5.0.18.17,5.0.18.18,5.0.18.19,2.0.19.8,2.0.19.9,2.0.19.10,2.0.19.11,2.0.19.12,2.0.19.13,2.0.19.14,2.0.19.15,2.0.19.16,2.0.19.17,2.0.19.18,2.0.19.19,4.1.20.9,4.1.20.11,1.0.21.9,1.0.21.11,5.1.22.11,4.2.8.6,1.0.10.4,8.0.10.3,8.0.8.4,8.0.8.5,4.1.6.3,0.0.8.3,3.2.7.3,3.1.6.7,3.1.7.7,3.1.8.7,5.2.10.6,5.0.9.6,1.0.4.4,1.0.3.4,1.2.4.16,1.2.3.16,1.0.11.5,8.0.11.7,0.1.12.7,0.1.13.7,0.1.14.7,5.1.14.8,5.1.13.8,5.1.12.8,5.1.12.5,4.2.12.4,4.2.13.5,3.2.18.6,5.2.14.5,4.2.14.4,1.2.16.5,2.2.16.7,3.0.17.8,3.0.17.9,3.0.17.10,3.0.17.11,3.0.17.12,3.0.17.13,3.0.17.14,3.0.17.15,3.0.17.16,3.0.17.17,3.0.17.18,3.0.17.19,1.0.21.19,1.0.21.18,1.0.21.17,1.0.21.16,1.0.21.15,1.0.21.14,1.0.21.13,1.0.21.12,1.0.21.10,1.0.21.8,4.0.20.8,4.1.20.10,4.1.20.12,4.1.20.13,4.1.20.14,4.1.20.15,4.1.20.16,4.1.20.17,4.1.20.18,4.1.20.19,5.1.22.9,5.1.23.11,2.0.24.11,2.0.23.9,2.0.26.6,2.0.25.4,3.2.24.9,3.1.25.9,0.2.2.7,2.2.1.8,2.2.0.7,2.2.1.0,2.2.17.0,3.1.4.10,3.3.3.10,8.3.0.2;;"
    #level_data = "V1;29;7;;3.0.1.3,3.0.2.4,3.0.2.5,0.3.3.3,5.0.3.4,3.0.3.5,3.0.4.2,7.0.4.3,2.0.4.4,5.0.4.5,3.0.4.6,0.1.5.2,0.1.5.4,0.0.5.5,4.0.5.6,0.0.6.3,2.0.6.4,5.0.6.5,7.0.7.1,7.0.7.3,5.0.7.5,3.0.8.2,0.0.8.3,3.0.8.4,5.0.8.5,0.1.9.2,0.1.9.4,0.0.9.5,3.2.10.5,0.1.1.2,3.0.0.2,3.0.0.0,4.0.1.0,5.0.2.0,1.0.3.0,3.2.11.0,3.2.18.0,3.2.28.0;;"
    #^enemy mover with deleting stuff
    #level_data = "V1;16;12;;3.0.0.5,3.0.0.7,4.0.1.5,0.1.1.7,3.0.1.8,3.0.2.9,3.0.2.10,0.3.3.8,5.0.3.9,3.0.3.10,3.0.4.7,7.0.4.8,2.0.4.9,5.0.4.10,3.0.4.11,0.1.5.7,0.1.5.9,0.0.5.10,4.0.5.11,0.0.6.8,2.0.6.9,5.0.6.10,7.0.7.6,7.0.7.8,5.0.7.10,3.0.8.7,0.0.8.8,3.0.8.9,5.0.8.10,0.1.9.7,0.1.9.9,0.0.9.10,3.2.10.10,3.0.4.4,0.0.5.4,3.0.13.3,5.0.14.3,2.0.15.3,3.0.13.6,5.0.14.6,2.0.15.6,1.0.3.4,2.0.4.3,3.0.2.3,3.0.1.4,5.0.2.4,5.0.3.3,3.0.1.0,5.0.2.0,1.0.3.0,1.1.5.0,0.0.4.0;;"




    UNIIN(level_data,2)



                
        #print(cellsBASE)



    cellsA = dcopy(cellsBASE)
    

    colors = [ #the base colors for each cell in RGB, see the details settup for... details
    (0,255,0),
    (0,0,255),
    (255,0,0),
    (50,200,50),
    (255,200,0),
    (255,200,0),
    (255,0,0),
    (255,0,255),
    (100,100,100),
    (100,100,100),
    (255,255,255),
    (0,255,255),
    ]

    default_details = [
     [[(255,255,255),(0.1,0.4),(0.6,0.4),(0.6,0.2),(0.8,0.5),(0.6,0.8),(0.6,0.6),(0.1,0.6)]],#duplicator
     [[(255,255,255),(0.2,0.2),(0.8,0.5),(0.2,0.8)]],#pusher
     [[(255,255,255),(0.2,0.7),(0.2,0.2),(0.8,0.2),(0.8,0.7),(0.9,0.7),(0.7,0.9),(0.5,0.7),(0.6,0.7),(0.6,0.6),(0.6,0.4),(0.4,0.4),(0.4,0.7)]],#cw rotator
     [],#ccw rotator
     [[(255,255,255),(0.2,0.2),(0.2,0.8),(0.8,0.8),(0.8,0.2)]],#omni block
     [[(255,255,255),(0.2,0.4),(0.2,0.6),(0.8,0.6),(0.8,0.4)]],#one-way block
     [[(0,0,0),(0.2,0.2),(0.4,0.4),(0.2,0.4)],[(0,0,0),(0.8,0.2),(0.6,0.4),(0.8,0.4)],[(0,0,0),(0.2,0.6),(0.8,0.6),(0.8,0.8),(0.7,0.8),(0.7,0.7),(0.3,0.7),(0.3,0.8),(0.2,0.8)]],#bad blob
     [],#bin
     [],#wall
     [[(255,255,255),(0.15,0.15),(0.5,0.1),(0.85,0.15),(0.85,0.5),(0.5,0.95),(0.15,0.5)]],#invinci
     [[(0,0,0),(0.2,0.2),(0.8,0.5),(0.2,0.8)]],#thing that rotates a singular cell 180*
     [[(0,0,0),(0.15,0.1),(0.4,0.1),(0.4,0.9),(0.15,0.9)],[(0,0,0),(0.6,0.1),(0.85,0.1),(0.85,0.9),(0.6,0.9)]],#pause cell
    ]
    for i in range(len(default_details[2])):
        default_details[3].append([])
        default_details[3][i].append(default_details[2][i][0])
        for j in default_details[2][i][1:]:
            default_details[3][i].append((j[0]*-1+1,j[1]))

    details = dcopy(default_details)
    texture_packs = os.listdir("./texture_packs")
    #print(texture_pack_folders)
    for i in range(len(texture_packs)-1,-1,-1):
        if "." in texture_packs[i]:
            texture_packs.pop(i)
    #print(texture_pack_folders)
    texture_images_names = [
     "generator.png",
     "mover.png",
     "CWspinner_alt.png",
     "CCWspinner_alt.png",
     "push.png",
     "slide.png",
     "enemy.png",
     "trash.png",
     "immobile.png",
    ]
    

    UI = [
     [[(255,255,255),(0,0),(1,0.5),(0,1)]],
     [[(255,255,255),(0,0),(0.1,0),(0.1,1),(0,1)],[(255,255,255),(0.2,0),(1,0.5),(0.2,1)]],
     dcopy(details[2]),
     [[(255,255,255),(0,0),(1,0),(0.5,1)]],
     [[(255,255,255),(0,1),(1,1),(0.5,0)]],
     [[(255,255,255),(0,0),(1,0),(0.5,1)]],
     pygame.image.load("./textures/save.png"),
     pygame.image.load("./textures/load.png"),
     pygame.image.load("./textures/select_move.png"),
     pygame.image.load("./textures/select_copy.png"),
     pygame.image.load("./textures/change_texture_pack.png"),
    ]

    UI_positions = [
        (1,1,(True,True),0),
        (2,1,(True,True),0),
        (1,2,(False,True),0),
        (-1,-1,(True,True),0),
        (-1,2,(True,True),0),
        (-1,1,(True,True),0),
        (-3.5,-1,(True,True),1),
        (-2.5,-1,(True,True),1),
        (-3.5,1,(True,False),1),
        (-2.5,1,(True,False),1),
        (-5,-1,(True,True),1),
        ] #[x,y,(display before start?,display after start?),type (poly, sprite)]

    cur_size = (UI_size, UI_size)
    for i in range(len(UI_positions)):
        if UI_positions[i][3] == 1:
            #print(i)
            UI[i] = pygame.transform.scale(UI[i], cur_size)

    #Text stuff
    TUI = [] #[[rendered text, center in pixels from top left, when to delete (-1 if never), min frame_calcs to delete]]

    MUI = [] #[[["square", relative to what? ("ms","bk","sr"), [[x,y],[x,y]]],["button", rtw?, [x,y],delete when pressed?, function when pressed]]]

    SUI = [] #[[shape ("square"),[x,y,width,height], color when to delete (-1 if never), min frame_calcs to delete]]


    pygame.display.set_caption("Pyll Machine")
    screen = pygame.display.set_mode((gx,gy))
    

    pygame.mixer.init(frequency=48000)
    #chan = pygame.mixer.find_channel()
    try:
        music = pygame.mixer.Sound("./PyllMachineMaybeTheme.mp3")
        music.set_volume(sound_level*music_level)
        music.play(-1)
    except:
        print("Music load error")
        

    old_pressed = pygame.key.get_pressed()

    if False:
        txt = "'clipboard' not working\nThe game will still run, but copy & pasting is done via command line"
        cur_wait = 7500
        txt_size = 30
        color = (255,255,255)
        comp.Text(0.5,0.5,txt,txt_size,color,cur_wait,1,TUI)

    #pygame.mouse.set_visible(False)
    '''
    thickarrow_strings = (               #sized 16x16 
      "XX              ",
      "XXX             ",
      "XXXX            ",
      "XX.XX           ",
      "XX..XX          ",
      "XX...XX         ",
      "XX....XX        ",
      "XX.....XX       ",
      "XX......XX      ",
      "XX.......XX     ",
      "XX.......XXX    ",
      "XX.....Xxx      ",
      "XX...XXX        ",
      "XX.XXX          ",
      "XXXX            ",
      "XX              ")'''
    thickarrow_strings = (               #sized 8x8 
      "XX      ",
      "XXX     ",
      "XXXX    ",
      "XX.XX   ",
      "XX..XX  ",
      "XX.XXX  ",
      "XXXX    ",
      "XX      ")
    '''
    thickarrow_strings = (               #sized 16x16 
      "XXXXXXXXXXXXXXXX",
      "X......XX......X",
      "X.     XX     .X",
      "X.     XX     .X",
      "X.     XX     .X",
      "X.     XX     .X",
      "X.     XX     .X",
      "XXXXXXXXXXXXXXXX",
      "XXXXXXXXXXXXXXXX",
      "X.     XX     .X",
      "X.     XX     .X",
      "X.     XX     .X",
      "X.     XX     .X",
      "X.     XX     .X",
      "X......XX......X",
      "XXXXXXXXXXXXXXXX",
    )'''


    #print(len(thickarrow_strings),len(thickarrow_strings[0]))
    cursor = pygame.cursors.compile(thickarrow_strings, black='X', white='.', xor='o')
    #pygame.mouse.set_cursor((8, 8), (0, 0), *cursor)
        
    if fullscreen:
        pygame.display.toggle_fullscreen()

    #comp.Selection([[300,300],[600,600]],False,10,1000,1000,SUI,disar)


    running = True
    while running:
        #print(pygame.time.get_ticks())
        #pygame.mouse.set_pos((gx/2,gy/2))
        
        msX,msY = 0,0
        mousex,mousey = 0,0
        
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.MOUSEWHEEL:
                zom += event.y
            if cur_GUI == 1 or cur_GUI == 2:
                if event.type == pygame.KEYDOWN:
                    inUNICODE += event.unicode
                
        
        if pygame.time.get_ticks() > (render_last+render_gap): #"render" here means anything to do with IO

            
            render_last = pygame.time.get_ticks()

            mixer.main(sound_level)
            

            
            inrot = 0
            input_key = -1
            pressed = pygame.key.get_pressed()
            if frame_render % output_gap == 0:
                cur_time = pygame.time.get_ticks()
                #adds the FPS and GPS counters
                txt = "FPS:"+str(10000//delta_render/10)+"\nTPS:"
                if frame_calc > 0 and (play or skip):
                    dif = frame_calc-frame_calc_old
                    if delta_calc>delta_render or dif == 0:
                        txt += str(10000//delta_calc/10)
                    else:
                        #print(dif/(cur_time-last_calc))
                        #print(10000//delta_calc/10, dif/(cur_time-last_calc)*1000,delta_calc)
                        txt += str(flr((dif/(cur_time-last_calc))*1000))
                else:
                    txt += "N/A"
                txt = txt + "\nTicks: "+str(frame_calc)
                txt = txt + "\nVol: "+str(flr(sound_level*100))
                    
                txt_size = 30
                color = (255,255,255)
                comp.Text(0.075,0.075,txt,txt_size,color,0,output_gap,TUI)
                frame_calc_old = frame_calc
                last_calc = cur_time

            if pressed[pygame.K_LCTRL]:
                ctrl = True
            else:
                ctrl = False
            if (pressed[pygame.K_w] and ctrl):
                running = False
            if pressed[pygame.K_F11] and not old_pressed[pygame.K_F11]:
                fullscreen = not fullscreen
                set_fullscreen(disar,fullscreen,autoset)
            if pressed[pygame.K_HASH] and not old_pressed[pygame.K_HASH]:
                slow_zoom = -0.02
            if ctrl:
                slow_zoom = 0
            zom += slow_zoom



            old_ms = ms
            old_ms_pos = ms_pos
            old_disar = dcopy(disar)
            old_click = click
            ms = pygame.mouse.get_pressed()
            ms_pos = pygame.mouse.get_pos()
            msx = ms_pos[0]
            msy = ms_pos[1]
            msx_old = old_ms_pos[0]
            msy_old = old_ms_pos[1]
            click = ms[0] or pressed[pygame.K_SPACE]
            
            if cur_GUI == 0:
                
                if pressed[pygame.K_TAB]:
                    tab = True
                else:
                    tab = False
                if pressed[pygame.K_LSHIFT]:
                    shift = True
                else:
                    shift = False
                if (pressed[pygame.K_DOWN] and not old_pressed[pygame.K_DOWN]):
                    mousey += 1
                if (pressed[pygame.K_UP] and not old_pressed[pygame.K_UP]):
                    mousey -= 1
                if (pressed[pygame.K_RIGHT] and not old_pressed[pygame.K_RIGHT]):
                    mousex += 1
                if (pressed[pygame.K_LEFT] and not old_pressed[pygame.K_LEFT]):
                    mousex -= 1
                if (pressed[pygame.K_a]):
                    msX -= 1
                if (pressed[pygame.K_d]):
                    msX += 1
                if (pressed[pygame.K_w] and not ctrl):
                    msY -= 1
                if (pressed[pygame.K_s]):
                    msY += 1
                if pressed[pygame.K_1]:
                    if not shift:
                        input_key = 0
                    else:
                        input_key = 9
                if pressed[pygame.K_2]:
                    
                    if not shift:
                        input_key = 1
                    else:
                        input_key = 10
                if pressed[pygame.K_3]:
                    if not shift:
                        input_key = 2
                    else:
                        input_key = 11
                if pressed[pygame.K_4]:
                    input_key = 3
                if pressed[pygame.K_5]:
                    input_key = 4
                if pressed[pygame.K_6]:
                    input_key = 5
                if pressed[pygame.K_7]:
                    input_key = 6
                if pressed[pygame.K_8]:
                    input_key = 7
                if pressed[pygame.K_9]:
                    input_key = 8
                if pressed[pygame.K_DELETE] and not old_pressed[pygame.K_DELETE]:
                    if len(cur_ghosts[1]) == 0:
                        frame_calc = 0
                        play = False
                        midx = (disar[0][0]+disar[1][0])/2
                        midy = (disar[0][1]+disar[1][1])/2
                        difx = midx - disar[2][0]
                        dify = midy - disar[2][1]
                        disar[0][0] -= difx
                        disar[0][1] -= dify
                        disar[1][0] -= difx
                        disar[1][1] -= dify
                        cellsBASE = {}
                        cellsA = dcopy(cellsBASE)
                    else:
                        cur_ghosts[1] = {}
                    
                    
                

                if pressed[pygame.K_q] and not old_pressed[pygame.K_q]:
                    inrot -= 1
                if pressed[pygame.K_e] and not old_pressed[pygame.K_e]:
                    inrot += 1
                if pressed[pygame.K_COMMA] and not old_pressed[pygame.K_COMMA]:
                    zom = -1
                if pressed[pygame.K_PERIOD] and not old_pressed[pygame.K_PERIOD]:
                    zom = 1
                if pressed[pygame.K_MINUS] and not old_pressed[pygame.K_MINUS]:
                    zom = -1
                if pressed[pygame.K_EQUALS] and not old_pressed[pygame.K_EQUALS]:
                    zom = 1
                if pressed[pygame.K_LALT] and not old_pressed[pygame.K_LALT]:
                    render_ui = not render_ui
                    pygame.mouse.set_visible(render_ui)
                if (pressed[pygame.K_LCTRL] and pressed[pygame.K_v]) and not (old_pressed[pygame.K_LCTRL] and old_pressed[pygame.K_v]):
                    
                    copy_in()

                if (pressed[pygame.K_LCTRL] and pressed[pygame.K_c]) and not (old_pressed[pygame.K_LCTRL] and old_pressed[pygame.K_c]):
                    
                    
                        
                    out = UNIOUT(cellsA,use_V3,1,False)
                    SetC(out[0])
                    
                    txt = "The "+out[1]+" code has been copied to clipboard"
                    txt_size = 30
                    color = (255,255,255)
                    comp.Text(0.5,0.5,txt,txt_size,color,2000,1,TUI)
                    '''
                    else:
                        txt = "Since 'clipboard' is not working,\nthe code has been printed to the text console"
                        txt_size = 30
                        color = (255,255,255)
                        comp.Text(0.5,0.5,txt,txt_size,color,5000,1,TUI)
                        print("The V3 code:\n"+UNIOUT(cellsA,use_V3,True,False))'''
                if pressed[pygame.K_ESCAPE]:
                    cur_ghosts[1] = {}
                        
                old_pressed = pressed

                if mousex != 0 or mousey != 0: #for some reason this doesn't place it at exactly the next cell, probably do to division problems
                    difx = gx/abs(disar[0][0]-disar[1][0])*mousex
                    dify = gy/abs(disar[0][1]-disar[1][1])*mousey
                    if ctrl:
                        difx*=5
                        dify*=5
                    pygame.mouse.set_pos((ms_pos[0]+difx,ms_pos[1]+dify))              
                
                    
                    
                if inrot != 0:
                    if not ctrl:
                        cur_ghost[4] = ((cur_ghost[4]-4+inrot)%4+4)%4
                        

                #key = [*cellsA.keys()]


                #UI detection

                if frame_calc == 0:
                    difx = abs(disar[0][0]-disar[1][0])
                    dify = abs(disar[0][1]-disar[1][1])
                    px = msx/gx*difx + disar[0][0]
                    py = msy/gy*dify + disar[0][1]
                    px = flr(px+0.5)
                    py = flr(py+0.5)
                    cur_ghost[0:3] = [True,px,py]
                else:
                    cur_ghost[0] = False

                if ms[1]:
                    movx = abs(disar[0][0]-disar[1][0])/gx
                    movy = abs(disar[0][1]-disar[1][1])/gy
                    difx = ms_pos[0]-old_ms_pos[0]
                    dify = ms_pos[1]-old_ms_pos[1]
                    movx *= difx
                    movy *= dify
                    disar[0][0] -= movx
                    disar[0][1] -= movy
                    disar[1][0] -= movx
                    disar[1][1] -= movy

                
                if click or ms[2]:
                    menu = not old_click
                    if click:
                        for i in range(len(UI_positions)): #runs though the UI using similar code to displaying
                            curpos = UI_positions[i]
                            curpos2 = list(curpos)
                            curpos2[0:2] = [abs(curpos2[0])-1,abs(curpos2[1])-1]
                            if ((curpos2[2][0] and frame_calc == 0) or (curpos2[2][1] and frame_calc != 0)) and place_valid:
                                px = UI_base_gap*UI_size + (UI_button_gap * UI_size + UI_size)*curpos2[0]
                                py = gy - (UI_base_gap*UI_size + (UI_button_gap * UI_size + UI_size)*curpos2[1] + UI_size)

                                if curpos[0]<0:
                                    px = px*-1+gx-UI_size

                                if curpos[1]<0:
                                    py = py*-1+gy-UI_size
                                            
                                #creates a bounding box
                                top = py
                                bottom = py+UI_size
                                left = px
                                right = px+UI_size


                                
                                if msy >= top and msy <= bottom and msx >= left and msx <= right: #tests
                                    place_valid = False
                                    if menu:
                                        #checks which one it is
                                        if (i == 0 or i == 1) and frame_calc == 0:
                                            #print(frame_calc)
                                            midx = (disar[0][0]+disar[1][0])/2
                                            midy = (disar[0][1]+disar[1][1])/2
                                            disar[2][0] = midx
                                            disar[2][1] = midy
                                        if i == 0:
                                            play = not play
                                        elif i == 1:
                                            play = False
                                            skip = True
                                        elif i == 2:
                                            frame_calc = 0
                                            play = False
                                            cellsA = dcopy(cellsBASE)
                                            
                                            midx = (disar[0][0]+disar[1][0])/2
                                            midy = (disar[0][1]+disar[1][1])/2
                                            difx = midx - disar[2][0]
                                            dify = midy - disar[2][1]
                                            disar[0][0] -= difx
                                            disar[0][1] -= dify
                                            disar[1][0] -= difx
                                            disar[1][1] -= dify
                                        elif i == 3:
                                            
                                            #TUI = [] [rendered text, center in pixels from top left, when to delete (-1 if never, min frame_calcs to delete)]

                                            txt = """<zoom> is (mouse wheel), (- and +) or (, and .)
<click> is (left mouse button) or (space) (because my left mouse button is unreliable)
<mouse> is (mouse) or (arrow keys)

F11 to toggle fullscreen
WASD or (<mouse> and mouse 3) to move to move, <zoom> to zoom in and out
alt to hide all menus and the mouse, ctrl + w to close the game

shift + <zoom> to change the speed of the simulation

ctrl + c to copy the entire board in V2 format
ctrl + v to paste in any format
delete to delete the entire board

ctrl + <zoom> to switch blocks fluidly, q and e to rotate
1 to 9 to select blocks, shift + 1 to 3 to use the custom blocks

The arrows on the bottom right change the volume
Select and copy tools also on the bottom right
tab to activate white background"""
                                            txt_size = 23
                                            color = (255,255,255)
                                            comp.Text(0.5,0.5,txt,txt_size,color,5000,1,TUI)
                                            #[print(i) for i in TUI]
                                        elif i == 4:
                                            sound_level += sound_step
                                        elif i == 5:
                                            sound_level -= sound_step
                                        elif i == 6:
                                            cur_GUI = 1
                                            cur_text = ""
                                        elif i == 7:
                                            cur_GUI = 2
                                            cur_text = ""
                                        elif i == 8:
                                            cur_GUI = 3
                                        elif i == 9:
                                            cur_GUI = 4
                                        elif i == 10:
                                            cur_texture_pack += 1
                                            if cur_texture_pack >= len(texture_packs):
                                                cur_texture_pack = -1
                                                details = dcopy(default_details)
                                            else:
                                                cur_name = texture_packs[cur_texture_pack]
                                                cur_folder_path = "./texture_packs/"+cur_name+"/"
                                                #try:
                                                if True:
                                                    
                                                    for j in range(len(texture_images_names)):
                                                        cur_details = []
                                                        #print(texture_images_names[j])
                                                        img = Image.open(cur_folder_path+texture_images_names[j])
                                                        img = img.convert("RGBA")
                                                        pixels = img.load()
                                                        cur_size = img.size

                                                        for cur_x in range(cur_size[0]):
                                                                buildup = 0
                                                                for cur_y in range(cur_size[1]):
                                                                    rgba = pixels[cur_x,cur_y]
                                                                    
                                                                    if rgba[3] > 0:
                                                                        buildup += 1
                                                                        
                                                                        if cur_y+1 != cur_size[1]:
                                                                            nxt = pixels[cur_x,cur_y+1]
                                                                            #if nxt != rgba and nxt[3] < 255:
                                                                            #    print(rgba,nxt)
                                                                            #print(rgba,nxt,rgba==nxt)
                                                                            
                                                                            if rgba != nxt:
                                                                                valid = True
                                                                            else:
                                                                                valid = False
                                                                        else:
                                                                            valid = True

                                                                    
                                                                            
                                                                        if valid:
                                                                            tl = [cur_x/cur_size[0],(cur_y-buildup+1)/cur_size[1]]
                                                                            br = [(cur_x+1)/cur_size[0],(cur_y+1)/cur_size[1]]
                                                                            tr = [br[0],tl[1]]
                                                                            bl = [tl[0],br[1]]

                                                                            cur_details.append([rgba[:3],tl,tr,br,bl])
                                                                            #print([rgba[:3],tl,tr,br,bl])
                                                                            buildup = 0
                                                                buildup = 0
                                                        details[j] = dcopy(cur_details)
                                                                            
                                                #except:
                                                #    print("texture pack error")
                                                        
                                                        
                                                
                                                
                                            #print(cur_texture_pack)
    
                                            
                                            
                                            
                                        
                    #print(valid)
                
                    if place_valid and frame_calc == 0 and not (play or skip): #does block placement
                        
                        #print(px,py,disar)
                        #[type,rotation,oldx,oldy,current rotation,old rotation]
                        difx = abs(disar[0][0]-disar[1][0])
                        dify = abs(disar[0][1]-disar[1][1])
                        px = msx/gx*difx + disar[0][0]
                        py = msy/gy*dify + disar[0][1]
                        px = flr(px+0.5)
                        py = flr(py+0.5)
                        px_old = msx_old/gx*difx + old_disar[0][0]
                        py_old = msy_old/gy*dify + old_disar[0][1]
                        px_old = flr(px_old+0.5)
                        py_old = flr(py_old+0.5)

                        pixels = line_render((px_old,py_old),(px,py))

                        if ready_to_place:
                            if click:
                                if len(cur_ghosts[1])==0:
                                    for i in pixels:
                                        cellsBASE[(i[0],i[1])] = [cur_ghost[3],cur_ghost[4],i[0],i[1],cur_ghost[4],cur_ghost[4]]
                                    #print(cellsBASE[(px,py)])
                                else:

                                    for i in cur_ghosts[1]: #uses almost identical logic to rendering, and steals other code from there as well
                                        cur_cell = cur_ghosts[1][i]
                                        off_x,off_y = cur_ghosts[2][0]//2,cur_ghosts[2][1]//2
                                        new_x = i[0]-off_x+px
                                        new_y = i[1]-off_y+py
                                        
                                        
                                        cellsBASE[(new_x,new_y)] = cur_cell
                                    cur_ghosts[1] = {}
                                    ready_to_place = False
                            elif ms[2]:
                                for i in pixels:
                                    if (i[0],i[1]) in cellsBASE:
                                        cellsBASE.pop((i[0],i[1]))
                            if click or ms[2]:
                                cellsA = dcopy(cellsBASE)
                    
                            
                else:
                    place_valid = True
                    ready_to_place = True
                
                    
                if sound_level != sound_level_old:
                    try:
                        music.set_volume(sound_level*music_level)
                    except:
                        None
                    if sound_level > 1:
                        sound_level = 1
                    elif sound_level < 0:
                        sound_level = 0
                sound_level_old = sound_level
                    
                    
                    

                
                #print(play)
                #print(frame_calc)
                        
                
                
                
                #level_data = "V1;50;50;;3.0.23.21,3.0.24.21;;"
                #^Two pushers

                delt = delta if delta > render_gap else render_gap #sets a more real delta, not the best so I'll fix it later
                
                if msX != 0 or msY != 0:
                    
                    panx = msX*pan_speed[0]*delt/1000
                    pany = msY*pan_speed[1]*delt/1000
                    difx = abs(disar[0][0]-disar[1][0])
                    dify = abs(disar[0][1]-disar[1][1])
                    panx *= difx
                    pany *= dify
                    disar[0][0]+=panx
                    disar[0][1]+=pany
                    disar[1][0]+=panx
                    disar[1][1]+=pany
                
                if input_key != -1:
                    cur_ghost[3] = input_key
                    
                if zom != 0:
                    if (pressed[pygame.K_LSHIFT]):
                        if zom > 0:
                            muli = 1/calc_mult
                        else:
                            muli = calc_mult
                        calc_gap *= muli
                    
                    elif (pressed[pygame.K_LCTRL]):
                        cur_ghost[3] = (cur_ghost[3]+flr(zom))%len(colors)
                        
                    
                    else:
                        outx = (disar[0][0]+disar[1][0])/2
                        outy = (disar[0][1]+disar[1][1])/2

                        muli = zoom_speed**(-zom)
                        #print(muli,outx,disar)
                        disar[0][0] = (disar[0][0]-outx)*muli+outx
                        disar[0][1] = (disar[0][1]-outy)*muli+outy
                        disar[1][0] = (disar[1][0]-outx)*muli+outx
                        disar[1][1] = (disar[1][1]-outy)*muli+outy
                        #print(disar)
                zom = 0


            
            elif cur_GUI == 1 or cur_GUI == 2: #okay, so this entire overly-complicated section does saving and loading via files
                if pressed[pygame.K_ESCAPE] == 1:
                    cur_GUI = 0

                files = showF("saves")
                
                if inUNICODE != "":
                    
                    
                    
                    
                    frst = ord(inUNICODE[0])
                    if frst == 8: #backspace
                        if len(cur_text)>0:
                            cur_text = cur_text[:-1]
                    elif frst == 9: #tab
                        
                        
                        ln = len(cur_text)
                        
                        valid = True
                        while valid:
                            st = set()
                            fails = 0
                            ln = len(cur_text)
                            for i in files:
                                if len(i)>=ln:
                                    if cur_text==i[0:ln]:
                                        if len(i)>ln:
                                            st.add(i[ln])
                                        else:
                                            fails += 1
                                            valid = False
                            
                            
                            #print(st)               
                            if len(st)==1:
                                #print("OK")
                                if fails == 0:
                                    cur_text+=list(st)[0]
                            elif len(st)>1:
                                #print("not ok")
                                valid = False
                                cur_text = cur_text[0:-1]
                            else:
                                #print("not ok")
                                valid = False
                            #print(valid)
                            #if fails > 0:
                            #    cur_text = cur_text[0:-1]
                        
                    elif frst == 13: #enter
                        if cur_GUI==1:
                            saveF("saves",cur_text,cellsA,use_V3)
                            mixer.create("./sound_effects/save tone.mp3",5,500,0.5,5)
                        elif cur_GUI==2:
                            ln = len(cur_text)
                            standard_files = []
                            for i in files:
                                if len(i)>=ln:
                                    if cur_text==i[0:ln]:
                                        standard_files.append(i)
                            if len(standard_files)>0:
                                
                                loadF("saves",standard_files[0],2)
                                frame_calc = 0
                
                                play = False
                                cellsA = dcopy(cellsBASE)
                                
                                midx = (disar[0][0]+disar[1][0])/2
                                midy = (disar[0][1]+disar[1][1])/2
                                difx = midx - disar[2][0]
                                dify = midy - disar[2][1]
                                disar[0][0] -= difx
                                disar[0][1] -= dify
                                disar[1][0] -= difx
                                disar[1][1] -= dify
                                mixer.create("./sound_effects/paste tone.mp3",5,500,1,5)
                        else:
                            print("This is a bug, how did you even get here?")
                        cur_GUI = 0
                    else: #literally anything else
                        cur_test = cur_text+inUNICODE

                        

                        if cur_GUI == 2:
                            for i in files:
                                if len(i)>=ln:
                                    if cur_text==i[0:ln]:
                                        if cur_test==i[0:len(cur_test)]:
                                            valid = True
                        else:
                            valid = True
                        if valid:
                            cur_text+=inUNICODE
                    #print(ord(inUNICODE[0]))

                    inUNICODE = ""

                if len(cur_text)>0:
                    txt = cur_text
                else:
                    txt = "enter text, please"

                txt += "\n"

                files = showF("saves")

                ln = len(cur_text)
                to_do = files_shown
                for i in files:
                    if len(i)>=ln:
                        if cur_text==i[0:ln]:
                            if to_do > 0:
                                to_do -= 1
                                txt+=("\n"+i)
                for i in range(to_do):
                    txt+="\n"
                
                    

                    
                txt_size = 23
                color = (255,255,255)
                comp.Text(0.5,0.5,txt,txt_size,color,0,1,TUI)

            
            elif cur_GUI == 3 or cur_GUI == 4 or cur_GUI == 5 or cur_GUI == 6:
                
                #This section is to handle selecting and duplicating
                #It's garbage
                
                if pressed[pygame.K_ESCAPE] == 1:
                    cur_GUI = 0
                
                if cur_GUI == 3 or cur_GUI == 4:
                    if old_click and not click:
                        cur_GUI += 2
                        ready = False
                #print(cur_GUI)
                
                
                if cur_GUI == 5 or cur_GUI == 6:
                    if click:
                        cur_ghost[0] = False
                        ready = True
                        difx = abs(disar[0][0]-disar[1][0])
                        dify = abs(disar[0][1]-disar[1][1])
                        px = msx/gx*difx + disar[0][0]
                        py = msy/gy*dify + disar[0][1]
                        px = flr(px+0.5)
                        py = flr(py+0.5)

                        if not old_click:
                            select_area = [[px,py],[px,py]]
                        else:
                            select_area[1] = [px,py]
                        comp.Selection(select_area,True,flr(Selection_width*UI_size),0,1,SUI,disar)
                    elif ready:
                        cur_ghost[0] = True

                        tl_x = min(select_area[0][0],select_area[1][0])
                        tl_y = min(select_area[0][1],select_area[1][1])
                        br_x = max(select_area[0][0],select_area[1][0])
                        br_y = max(select_area[0][1],select_area[1][1])

                        #print(tl_x,tl_y,br_x,br_y)

                        new_dict = {}

                        
                        for i in cellsBASE:
                            if i[0] >= tl_x and i[0] <= br_x and i[1] >= tl_y and i[1] <= br_y:
                                #print(cellsBASE[i])
                                new_dict[i] = cellsBASE[i]
                            
                        #print(new_dict)
                        if cur_GUI == 5:
                            for i in new_dict:
                                cellsBASE.pop(i)
                            cellsA = dcopy(cellsBASE)

                        maybe_level_code = UNIOUT(new_dict,use_V3,1,False)
                        if maybe_level_code != None:
                            level_code = maybe_level_code[0]
                            #print(level_code)

                        
                            if len(level_code) > 0:
                                SetC(level_code+"segment")
                            copy_in()

                        cur_GUI = 0
                        zom = 0
                        
                        
                
            #
            #key = [*cellsA.keys()]
            #print(key)
            #for i in key:
            #    print(i,cellsA[i])
            #halt

            #key = [*cellsA.keys()]
            render()

            frame_render += 1

            delta_render2 = pygame.time.get_ticks()
            delta_render = delta_render2-delta_render1
            delta_render1 = pygame.time.get_ticks()

            renders_cur = delta_render/calc_gap/1.5 #this is broken, but the 1.5 "fixes" it without a lot of effort

            #print(cellsBASE,cur_ghosts)








        
        if not (play or skip):
            calc_last = pygame.time.get_ticks()-calc_gap

        high_speed = (calc_gap*min_calc_ratio<=render_gap and renders_cur >= 1)
        if not high_speed:
            low_speed = pygame.time.get_ticks() > (calc_last+calc_gap)
        if (low_speed or high_speed) and (play or skip): #the [time] > [last time] + [time gap] allows for easy speed changes 
            if frame_calc == 0: # since the main dicts get reset
                cellsGEN,cellsROT,cellsPSH = {},{},{}
                all_the_dicts = [cellsGEN,cellsROT,cellsPSH]
                find.change(all_the_dicts)
                #print(all_the_dicts)
                for i in cellsA:
                    cur = find.dict(cellsA[i][0])
                    if cur != None:
                        #print("OK")
                        cur[i] = cellsA[i].copy()
                #print("NEW START")
                #print(all_the_dicts,"\n",cellsA)

            renders_cur -= 1
            
            #print(frame_calc)
            frame_calc += 1

            

            #print(calc_gap)
            skip = False
            #print("OK")
            calc_last = pygame.time.get_ticks()
            
            
            #print(cellsA)
            key = [*cellsA.keys()]
            for i in key:
                cellsA[i][2:4] = list(i)
                cellsA[i][5] = cellsA[i][4]
            
        
            #this algorith is really ineficient, it runs though everything in the dict 12 times
            #stuff like rotators are done based on the rotating logic of the rest of the script, thus taking 4 times as long
            #the constant sorting and copying of both {cells} have a big O notation of n^2, meaning scaling'll get bad
            
            
            
            
            for des in range(3): #checks for duplicators, rotators, then pushers in the same bowl of spaghetti
                
                cur_dict = all_the_dicts[des]

                
                

                
                for rot in [0,2,3,1]: #the order is weird, ok?
                    
                    
                    key = [*cur_dict.keys()]
                    #print(des,rot)
                    #print(cellsA,cur_dict)
                    if des == 0 or des == 2: #It doesn't really matter with rotaters
                        key.sort(reverse=(rot<=1))
                    #print(rot,(rot<=2))
                    #render()
                    for i in key:
                        #print(key,cellsA)
                        #print(rot,cellsA[i])
                        #print("t",cur_dict)
                        
                        
                        #print(cellsA)
                        cur = cellsA[i]

                        xdif,ydif = 0,0

                        if (cur[0] == 2 or cur[0] == 3 or cur[0] == 10):
                            if rot == 0: #the same as the pusher one, but different enough to require different code
                                xdif = 1
                            elif rot == 1:
                                ydif = 1
                            elif rot == 2:
                                xdif = -1
                            elif rot == 3:
                                ydif = -1
                            newx = i[0] + xdif
                            newy = i[1] + ydif
                        
        
                        if (cur[0] == 2 or cur[0] == 3) and des == 1: #does rotator logic
                            
                            
                            
                            if (newx,newy) in cellsA:
                                
                                rotation = ((cur[0]-2)*2-1)*-1 #outputs a negative if ccw, positive if cw
                                rotation = cellsA[(newx,newy)][4] + rotation #adds that to the curent rotation of the cell
                                cellsA[(newx,newy)][4] = rotation #outputs the raw value
                                rotation = ((rotation)%4+4)%4 #bodge job to get it in the 0-3 range, not nesesary but looks nicer
                                cellsA[(newx,newy)][1] = rotation #outputs it to the cell
                                if cellsA[(newx,newy)][0]==11:
                                    play=False
                        
                        if (cur[0] == 10) and des == 1 and cur[1] == rot: #does the 180* rotator logic


                            if (newx,newy) in cellsA:
                                
                                rotation = 2 #outputs... a 2
                                rotation = cellsA[(newx,newy)][4] + rotation #adds that to the curent rotation of the cell
                                cellsA[(newx,newy)][4] = rotation #outputs the raw value
                                rotation = ((rotation)%4+4)%4 #bodge job to get it in the 0-3 range, not nesesary but looks nicer
                                cellsA[(newx,newy)][1] = rotation #outputs it to the cell

                        if cur[1] == 0: #a line of ifs to see where it should be going, because... I cba to figure out the math
                            xdif = 1
                        elif cur[1] == 1:
                            ydif = 1
                        elif cur[1] == 2:
                            xdif = -1
                        elif cur[1] == 3:
                            ydif = -1
                        
                        pusher_check = (cur[0] == 1 and des == 2)
                        duplicator_check = (cur[0] == 0 and des == 0 and ((i[0]-xdif,i[1]-ydif) in cellsA))
                        
                        #print(all_the_dicts,cellsA,"1")
                        if cur[1] == rot and (pusher_check or duplicator_check): #does pusher + duplicator logic
                            #if duplicator_check:
                            #    print(cur)
                            #render()
                            #print("OK",i)
                            power = 1 #controls the tests for counter-pushers
                            valid = True
                            cont = False
                            newx = i[0]
                            newy = i[1]
                            while valid and not cont: #checks the spaces in front to see if it should move
                                oldx = newx
                                oldy = newy
                                newx += xdif
                                newy += ydif
                                if (newx,newy) in cellsA:
                                    tst = cellsA[(newx,newy)]
                                    invinci_test = cellsA[(oldx,oldy)][0] != 9
                                    if tst[0] == 8: #checks for wall
                                        valid = False
                                    if tst[0] == 5: #checks for one-way blocks
                                        if tst[1]%2 == cur[1]%2: #checks their rotation
                                            valid = True
                                        else:
                                            valid = False
                                    if ((tst[0] == 6 and invinci_test) or (cellsA[(oldx,oldy)][0] == 6 and tst[0] != 9) or tst[0] == 7): #checks for enemys, ignores them
                                        valid = True
                                        cont = True
                                    if cellsA[(newx,newy)][0] == 1: #checks for counter-pushers
                                        dif = abs(cur[1]-cellsA[(newx,newy)][1])
                                        filt = ((dif+1)%2) #results in a 0 if it's perpendicular to it
                                        dif = ((dif-1)*filt)*-1 #outputs a -1 if against it, 1 if with it, and 0 if perpendicular to it
                                        #print(dif)
                                        power += dif      
                                else:
                                    valid = True
                                    cont = True
                                #print(power)
                                if power == 0:
                                    #print(power)
                                    valid = False
                                elif power < 0:
                                    print("BUG WITH THE POWER SYSTEM")
                                
                            #print(all_the_dicts,cellsA,"2")
                            if valid:
                                if cur[0] == 0:
                                    cur_key = (i[0]+xdif,i[1]+ydif)
                                elif cur[0] == 1:
                                    cur_key = i
                                else:
                                    print("BUG WITH THE CUR_KEY SYSTEM")
                                while newx != cur_key[0] or newy != cur_key[1]: #moves all the blocks along
                                    maybe_dict = find.dict(cellsA[(newx-xdif,newy-ydif)][0])
                                    


                                    #print(all_the_dicts,cellsA,"3")
                                    
                                    
                                    if (newx,newy) in cellsA:
                                        maybe_dict_new = find.dict(cellsA[(newx,newy)][0])
                                        #print("There's a thing there")
                                        
                                        tst = cellsA[(newx,newy)]
                                        
                                        if maybe_dict != None:
                                            #print("DEAD")
                                            maybe_dict.pop((newx-xdif,newy-ydif))
                                        if maybe_dict_new != None:
                                            #print(cellsA,maybe_dict_new,(newx-xdif,newy-ydif))
                                            
                                            maybe_dict_new.pop((newx,newy))
                                        #print(tst,cellsA[(newx-xdif,newy-ydif)])
                                        if tst[0] == 7:
                                            cellsA.pop((newx-xdif,newy-ydif))
                                        
                                        elif tst[0] == 6 or (cellsA[(newx-xdif,newy-ydif)][0] == 6):
                                            
                                            #print("OK")
                                            cellsA.pop((newx,newy))
                                            cellsA.pop((newx-xdif,newy-ydif))
                                            
                                        else:
                                            print("BUG WITH THE MOVEMENT SYSTEM", cellsA[(newx-xdif,newy-ydif)],tst)
                                            #print((newx,newy))
                                            #cellsA[(newx,newy)] = cellsA.pop((newx-xdif,newy-ydif))
                                    else:
                                        if maybe_dict != None:
                                            maybe_dict[(newx,newy)] = maybe_dict.pop((newx-xdif,newy-ydif))
                                        cellsA[(newx,newy)] = cellsA.pop((newx-xdif,newy-ydif))
                                        if cellsA[(newx,newy)][0]==11:
                                            play=False
                                    newx -= xdif
                                    newy -= ydif
                                
                                if cur[0] == 0: #extra bit to do the block duplication
                                    valid = True
                                    die = False

                                    if (i[0]-xdif,i[1]-ydif) in cellsA:
                                        if cellsA[(i[0]-xdif,i[1]-ydif)][0]==11:
                                            play=False
                                    
                                    if cur_key in cellsA:
                                        if cellsA[cur_key][0] == 6:
                                            valid = False
                                            die = True
                                        if cellsA[cur_key][0] == 7:
                                            valid = False
                                            die = False

                                            
                                    
                                    if valid:
                                        if cellsA[(i[0]-xdif,i[1]-ydif)][0] == des:
                                            cur_dict[cur_key] = cur_dict[(i[0]-xdif,i[1]-ydif)].copy()
                                        cellsA[cur_key] = cellsA[(i[0]-xdif,i[1]-ydif)].copy()

                                        maybe_dict = find.dict(cellsA[cur_key][0])
                                        
                                        if maybe_dict != None:
                                            #print("Thing coppied")
                                            maybe_dict[cur_key] = cellsA[cur_key].copy()

                                        cellsA[cur_key][2:4] = list(i)
                                        #^block goes from the duper
                                        #cellsA[cur_key][2:4] = [i[0]+xdif,i[1]+ydif]
                                        #^block goes from the front of the duper
                                        
                                    if die:
                                        cellsA.pop(cur_key)
            
            delta_calc2 = pygame.time.get_ticks()
            delta_calc = delta_calc2-delta_calc1
            delta_calc1 = pygame.time.get_ticks()
            if False:
                if cellsBASE.keys() == cellsA.keys():
                    txt_size = 23
                    color = (255,255,255)
                    comp.Text(0.5,0.5,str(frame_calc),txt_size,color,1000,1,TUI)
                    print(frame_calc)
            #print(frame_calc)
        else:
            'print("OK")'

            
        
        
        delta1 = pygame.time.get_ticks()
        delta = delta1 - delta2
        delta2 = pygame.time.get_ticks()
        
        
        
    pygame.quit()
