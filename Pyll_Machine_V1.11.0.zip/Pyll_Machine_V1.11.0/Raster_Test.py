import sys as trans
from math import ceil, floor as flr, sqrt, pi, sin, cos
rnd = round


def mflr(lst):
    out = []
    for i in lst:
        out.append(flr(i))
    if type(lst) == type((1,2)):
        out = tuple(out)

    return out

def mint(lst):
    out = []
    for i in lst:
        out.append(sint(i))
    if type(lst) == type((1,2)):
        out = tuple(out)

    return out

def sint(flot):
    if flot > 0:
        return (flr(flot))
    else:
        return(ceil(flot))

def mround(lst):
    out = []
    for i in lst:
        out.append(round(i))
    if type(lst) == type((1,2)):
        out = tuple(out)

    return out

def line_render(srt,end):
    pixels = []
    
    xoff = end[0]-srt[0]
    yoff = end[1]-srt[1]

    if abs(yoff) < abs(xoff):
        flip = False
    else:
        flip = True
        #print("OK")
        xoff,yoff = yoff,xoff
        srt = (srt[1],srt[0])
        end = (end[1],end[0])

    
        
    
    if yoff<0:
        y_move = -1
    else:
        y_move = 1
    
    if xoff<0:
        x_move = -1
    else:
        x_move = 1
    fxoff = sint(xoff)
    fyoff = sint(yoff)
    
    
    A = 2*fyoff*y_move
    B = A - 2*fxoff*x_move
    P = A - fxoff*x_move
    last = srt[1]

    pixels.append(convert((srt[0],last),(0,0),flip))

    for i in range(x_move+rnd(srt[0]),ceil(xoff)+rnd(srt[0])-1+((x_move+1)//2),x_move):
        if P < 0:
            pixels.append(convert((i,last),(0,0),flip))
            P += A
        else:
            last += y_move
            pixels.append(convert((i,last),(0,0),flip))
            P += B
    return pixels

def convert(xy,off,flip):
    if flip:
        (y,x) = xy
    else:
        (x,y) = xy
    x += off[0]
    y += off[1]
    return (x,y)

def circle_render_simple(srt,end):
    x0,y0 = (srt[0]+end[0])/2,(srt[1]+end[1])/2
    difx = abs(srt[0]-end[0])
    dify = abs(srt[1]-end[1])
    
    

    pixels = []
    if difx > 0 and dify > 0:
        if difx > dify:
            flip = False
        else:
            flip = True
            difx,dify = dify,difx
            
        r = difx/2
        ratio = dify/difx
        r2 = r**2
        #print(r2)
        #print(r2/2)
        #print(sqrt(r2))
        part = flr(sqrt(r2/2))
        #print(part,r)
        #print(part3)
        
        
        for i in range(-part-1,part+2):

            cur_y = (sqrt(r2-(i**2)))
            pixels.append(mflr(convert(mflr((i,cur_y*ratio)),(x0,y0),flip)))
            pixels.append(mflr(convert(mflr((i,-cur_y*ratio)),(x0,y0),flip)))
            pixels.append(mflr(convert(mflr((cur_y,i*ratio)),(x0,y0),flip)))
            pixels.append(mflr(convert(mflr((-cur_y,i*ratio)),(x0,y0),flip)))
    

    return pixels


def circle_render(srt,end):
    tl = (min(srt[0],end[0]),min(srt[1],end[1]))
    br = (max(srt[0],end[0]),max(srt[1],end[1]))
    difx = (br[0]-tl[0])/2
    dify = (br[1]-tl[1])/2

    detail = ceil(max(difx,dify)*10)
    

    pixels = set()
    #detail = 100
    for i in range(detail):
        t = i/detail*2*pi
        #print(sin(t))
        pixels.add(mround((sin(t)*difx+tl[0]+difx,cos(t)*dify+tl[1]+dify)))
    #print(pixels)
    #print(len(pixels))
    return pixels
        
    

def main():
    x,y = 600,600
    px = 10

    lines = [[(20,30),(13,12)],[(50,50),(55,45)]]
    circles = [[(20,30),(13,12)]]

    
    pygame.init()
    screen = pygame.display.set_mode((x,y))

    #logo = pygame.image.load("logo.png")
    #pygame.display.set_icon(logo)

    pygame.display.set_caption("Raster (is that the right word??) Test")
    
    
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
        screen.fill((0,0,0))
        
        ms = pygame.mouse.get_pos()
        lines[0][1] = (ms[0]/px,ms[1]/px)
        circles[0][1] = (ms[0]/px,ms[1]/px)
        
        for i in lines:
            srt = i[0]
            end = i[1]
            pixels = line_render(srt,end)
            for i in pixels:
                pygame.draw.rect(screen,(255,255,255),(i[0]*px,i[1]*px,px,px))

        for i in circles:
            srt = i[0]
            end = i[1]
            pixels = circle_render(srt,end)
            for i in pixels:
                pygame.draw.rect(screen,(255,255,255),(i[0]*px,i[1]*px,px,px))

        
            

            """
            
            if xoff<0:
                xneg = -1
                xoff = srt[0]-end[0]
            else:
                xneg = 1
                
            
            if yoff<0:
                yneg = -1
                yoff = srt[1]-end[1]
            else:
                yneg = 1
            
            fsrt = (flr(srt[0]),flr(srt[1]))
            fend = (flr(end[0]),flr(end[1]))
            
            if xoff > yoff:
                deg = yoff/xoff
                
                for i in range(ceil(xoff)):
                    cur_x = rnd(i*xneg+srt[0])
                    cur_y = rnd(i*deg*yneg+srt[1])
                    pygame.draw.rect(screen,(255,255,255),(cur_x*px,cur_y*px,px,px))
            else:
                deg = xoff/yoff

                for i in range(ceil(yoff)):
                    #print(i)
                    cur_x = rnd(i*deg*xneg+srt[0])
                    cur_y = rnd(i*yneg+srt[1])
                    pygame.draw.rect(screen,(255,255,255),(cur_x*px,cur_y*px,px,px))"""
                

        pygame.display.update()
    pygame.quit()

if __name__=="__main__":
    import pygame
    main()
