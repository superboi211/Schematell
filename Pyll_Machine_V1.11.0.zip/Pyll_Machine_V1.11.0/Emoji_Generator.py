#Hello there!
#This is a random thing I made in half an hour, that converts level codes to emojis
#If clipboard is installed, then it'll get and output the data via the clipboard
#
#Annnnd... that's it!


try:
    from clipboard import copy as SetC, paste as GetC
    clip = True
except:
    clip = False

from level import Level
level = Level(matcher_type=[0,2,3,1,5,4,8,6,7,9,10,11])


#for some reason the names of custom emoji change how many chars it takes up,
#whist the standard ones only use 1 or 2

compact = True #recomented
super_compact = True #switched to the old, smaller sprites
ultra_compact = True #switches to mostly built-in emoji

if super_compact:
    cells = [
        (":_gcr:",":_gcu:",":_gcl:",":_gcu:",),
        (":_bcr:",":_bcd:",":_bcl:",":_bcu:",),
        (":_ocr:",),
        (":_ocl:",),
        (":_ycc:",),
        (":_ych:",":_ycv:",),
        (":_ec:",),
        (":trash:",), #yeah, there isn't a smaller trash
        (":_ic:",),
    ]
else:
    cells = [
        (":generator_right:",":generator_down:",":generatorleft:",":generator_up:",),
        (":mover_right:",":mover_down:",":mover_left:",":mover_up:",),
        (":rotator_cw:",),
        (":rotator_ccw:",),
        (":push:",),
        (":slide_horizontal:",":slide_vertical:",),
        (":enemy:",),
        (":trash:",),
        (":wall:",),
    ]

if super_compact:
    nothing = ":black_large_square:"
elif compact:
    nothing = ":_uc:"
else:
    nothing = ":bg_default:"



if clip:
    lvl_code = GetC()
else:
    lvl_code = input("Please paste in the code:\n")

lvl = level.load_string(lvl_code,False)

out = ""

for y in range(len(lvl[0])-1,-1,-1):
    for x in range(len(lvl)):
        cur = lvl[x][y]
        if cur != None:
            out += cells[cur[0]][cur[1]%len(cells[cur[0]])]
        else:
            out += nothing
    out+="\n"


if clip:
    SetC(out)
else:
    print("\n"+out)


