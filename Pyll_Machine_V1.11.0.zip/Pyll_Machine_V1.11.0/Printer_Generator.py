import math, sys
from time import sleep
from math import floor as flr, ceil
from copy import deepcopy as dcopy
from random import random as rand
from Pyll_Machine import V1OUT

from PIL import Image as image
import json, numpy as np

def hx(integer):
    cur = str(hex(integer))[2:]
    while len(cur) < 2:
        cur = "0" + cur
    return cur
    
    


if __name__ == "__main__":
    imname = "New Piskel (6).png"



    img = image.open(imname)
    img = img.convert("RGBA")
    




    #print(hex(9),hex(10),str(hex(16))[2:])

    #print(pixels)
    #print(pixels[0,0])
    #cont = open("test3.txt","r").read().split("\n")

    #[print(i) for i in cont]
    #print(cont)



    
    dic = {}




    
    #img.show()
    pixels = img.load()
    (sx,sy) = img.size
    
    for y in range(sy):
        half = sx//2-1
        off = y*-7
        dic[(off,y)] = [3,0]
        dic[(off-3,y)] = [3,0]
        dic[(off-6,y)] = [3,0]
        dic[(off,y-half)] = [3,0]
        dic[(off-3,y-half)] = [3,0]
        dic[(off-6,y-half)] = [3,0]
        dic[(off-1,y+1)] = [0,1]
        dic[(off-4,y+1)] = [0,1]
        for x in range(sx):
            rgba = pixels[x,y]
            
            if rgba[3] > 0:
                backoff = 1
                py = x*7

                back = (x+(y%2))%2 == 0
                
                if back:
                    backoff += 3
                    py += 3
                if x > sx//2:
                    rot = 3
                else:
                    backoff += 1
                    rot = 1

                #print(py)
                py = ((py%(sx//2))+(sx//2))%(sx//2)-(sx//2)
                #print(py)

                if rot == 3:
                    py = (-(py))-(sx//2)
                else:
                    py += 1

                    
                
                

                if back:
                    py += 1
                
                #rot = 1
                
                dic[(off-backoff,y+py)] = [1,rot]
                

            
            
                

                
                
                
            #+(sx//2)

        
        

    






    print(V1OUT(dic))
